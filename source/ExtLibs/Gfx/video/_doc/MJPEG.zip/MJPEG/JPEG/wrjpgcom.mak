# Microsoft Developer Studio Generated NMAKE File, Based on wrjpgcom.dsp
!IF "$(CFG)" == ""
CFG=wrjpgcom - Win32
!MESSAGE Keine Konfiguration angegeben. wrjpgcom - Win32 wird als Standard verwendet.
!ENDIF 

!IF "$(CFG)" != "wrjpgcom - Win32"
!MESSAGE Ung�ltige Konfiguration "$(CFG)" angegeben.
!MESSAGE Sie k�nnen beim Ausf�hren von NMAKE eine Konfiguration angeben
!MESSAGE durch Definieren des Makros CFG in der Befehlszeile. Zum Beispiel:
!MESSAGE 
!MESSAGE NMAKE /f "wrjpgcom.mak" CFG="wrjpgcom - Win32"
!MESSAGE 
!MESSAGE F�r die Konfiguration stehen zur Auswahl:
!MESSAGE 
!MESSAGE "wrjpgcom - Win32" (basierend auf  "Win32 (x86) Console Application")
!MESSAGE 
!ERROR Eine ung�ltige Konfiguration wurde angegeben.
!ENDIF 

!IF "$(OS)" == "Windows_NT"
NULL=
!ELSE 
NULL=nul
!ENDIF 

CPP=cl.exe
RSC=rc.exe
OUTDIR=.\wrjpgcom\Release
INTDIR=.\wrjpgcom\Release
# Begin Custom Macros
OutDir=.\wrjpgcom\Release
# End Custom Macros

ALL : "$(OUTDIR)\wrjpgcom.exe"


CLEAN :
	-@erase "$(INTDIR)\vc60.idb"
	-@erase "$(INTDIR)\wrjpgcom.obj"
	-@erase "$(OUTDIR)\wrjpgcom.exe"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\wrjpgcom.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
LINK32_FLAGS=Release\jpeg.lib kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:console /incremental:no /pdb:"$(OUTDIR)\wrjpgcom.pdb" /machine:I386 /out:"$(OUTDIR)\wrjpgcom.exe" 
LINK32_OBJS= \
	"$(INTDIR)\wrjpgcom.obj"

"$(OUTDIR)\wrjpgcom.exe" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

CPP_PROJ=/nologo /G6 /MT /W3 /GX /Ox /Oa /Ob2 /D "WIN32" /D "NDEBUG" /D "_CONSOLE" /Fp"$(INTDIR)\wrjpgcom.pch" /YX /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

.c{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.c{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<


!IF "$(NO_EXTERNAL_DEPS)" != "1"
!IF EXISTS("wrjpgcom.dep")
!INCLUDE "wrjpgcom.dep"
!ELSE 
!MESSAGE Warning: cannot find "wrjpgcom.dep"
!ENDIF 
!ENDIF 


!IF "$(CFG)" == "wrjpgcom - Win32"
SOURCE=.\wrjpgcom.c

"$(INTDIR)\wrjpgcom.obj" : $(SOURCE) "$(INTDIR)"



!ENDIF 

