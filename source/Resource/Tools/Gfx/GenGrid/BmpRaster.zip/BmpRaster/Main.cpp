// SuperSizeMe.cpp : Definiert den Einsprungpunkt f�r die Konsolenanwendung.
//

#include <stdlib.h>
#include <stdio.h>

#define SUPER_SIZE_LINE_COL   BPP32_8R8G8B_RGB(0, 0, 0)

#include "_m_BPP32_8R8G8B_Tools.h"
#include "_m_BPP32_8R8G8B_Pattern.h"
#include "_m_BPP32_8R8G8B_Picture.h"
#include "_m_Screen.h"
#include "_TypeDef.h"

Screen mstTestScreen01;

int main(int argc, char* argv[])
{
  uint32 lui32NewWidth;
  uint32 lui32NewHeight;

  uint32 lui32BlockCntX;
  uint32 lui32BlockCntY;
  uint32 lui32BlockSizeX;
  uint32 lui32BlockSizeY;
  uint32 lui32DistUpperLine;
  uint32 lui32DistLowerLine;

  uint32 lui32t;
  uint32 lui32tX;
  uint32 lui32tY;

  char   lszDestFile[256];
  char   lszExtension[256];

  for(lui32t=0; lui32t < (uint32)argc; lui32t++)
  {
     printf("argv[%d] = %s ",lui32t,argv[lui32t]);
     printf("\n");
  }

  if (argc < 7) 
  {
    printf("At least one Parameter is missing !\n");
    printf("e.g. [BlockCntX] [BlockCntY] [BlockSizeX] [BlockSizeY] [DistLowerLine] [DistUpperLine] [DestBitmap]\n");
    printf("e.g. [BlockCntX]     = 16\n");
    printf("e.g. [BlockCntY]     = 16\n");
    printf("e.g. [BlockSizeX]    = 16\n");
    printf("e.g. [BlockSizeY]    = 16\n");
    printf("e.g. [DistLowerLine] = 2\n");
    printf("e.g. [DistUpperLine] = 2\n");
    printf("e.g. [DestBitmap]    = Test.Bmp\n");

    return 0;
  }

  lui32BlockCntX     = atoi(argv[1]);
  lui32BlockCntY     = atoi(argv[2]);
  lui32BlockSizeX    = atoi(argv[3]) + 1;
  lui32BlockSizeY    = atoi(argv[4]) + 1;
  lui32DistLowerLine = atoi(argv[5]);
  lui32DistUpperLine = atoi(argv[6]);

  if ((lui32BlockCntX < 1) || (lui32BlockCntX > 1023))
  {
    printf("[BlockCntX] Parameter is not ok !\n");
    return 0;
  }

  if ((lui32BlockCntY < 1) || (lui32BlockCntY > 1023))
  {
    printf("[BlockCntY] Parameter is not ok !\n");
    return 0;
  }

  if ((lui32BlockSizeX < 1) || (lui32BlockSizeX > 1023))
  {
    printf("[BlockSizeX] Parameter is not ok !\n");
    return 0;
  }

  if ((lui32BlockSizeY < 1) || (lui32BlockSizeY > 1023))
  {
    printf("[BlockSizeY] Parameter is not ok !\n");
    return 0;
  }


  strcpy(lszDestFile, argv[7]);
  strlwr(lszDestFile);

  if (strlen(lszDestFile) < 5) 
  {
    printf("Dest Image is missing !\n");
    return 0;
  }

  /*strncpy(lszExtension, lszDestFile + strlen(lszDestFile) - 3, 4);

  if (strcmp(lszExtension, "bmp") != 0) 
  {
    printf("Dest Image is wrong. Only BMP !\n");
    return 0;
  }*/

  ScreenInit(&mstTestScreen01);
        
  lui32NewWidth  =  lui32BlockCntX * lui32BlockSizeX;
  if (lui32NewWidth > 65535)  lui32NewWidth = 65535;

  lui32NewHeight =  lui32BlockCntY * lui32BlockSizeY;
  if (lui32NewHeight > 65535) lui32NewHeight = 65535;

  if (lui32NewWidth && lui32NewHeight)
  {                        
    ScreenCreate(BPP32_8R8G8B, 
                 (uint16)(lui32NewWidth),                                  
                 (uint16)(lui32NewHeight), 
                 &mstTestScreen01);

    BPP32_8R8G8B_ClearScreen(0, &mstTestScreen01);

    for (lui32tY = 0; lui32tY < lui32BlockCntY; lui32tY++)
    {
      uint32 lui32PosY;
      lui32PosY = lui32tY * lui32BlockSizeY;

      if (lui32DistUpperLine > 0)
      {
        BPP32_8R8G8B_CLine(0, lui32PosY + lui32DistUpperLine, (mstTestScreen01.ui16Width - 1), lui32PosY + lui32DistUpperLine, 0xFF0000, &mstTestScreen01);
        BPP32_8R8G8B_CLine(0, lui32PosY + lui32BlockSizeY - lui32DistLowerLine, (mstTestScreen01.ui16Width - 1), lui32PosY + lui32BlockSizeY - lui32DistLowerLine, 0xFF0000, &mstTestScreen01); 
      }

      for (lui32tX = 0; lui32tX < lui32BlockCntX; lui32tX++)
      {
        uint32 lui32PosX;

        lui32PosX = lui32tX * lui32BlockSizeX;


        BPP32_8R8G8B_CLine(lui32PosX, lui32PosY, lui32PosX + lui32BlockSizeX, lui32PosY, 0x00FF00, &mstTestScreen01); 
        BPP32_8R8G8B_CLine(lui32PosX, lui32PosY, lui32PosX, lui32PosY + lui32BlockSizeX, 0x00FF00, &mstTestScreen01); 
      }
    }

    BPP32_8R8G8B_BMPSave(lszDestFile, &mstTestScreen01);

    printf(lszDestFile);
    printf(" was generated \n");
  }
  else
  {
    printf("Was not able to make a raster !\n");
  }


	return 0;
}

