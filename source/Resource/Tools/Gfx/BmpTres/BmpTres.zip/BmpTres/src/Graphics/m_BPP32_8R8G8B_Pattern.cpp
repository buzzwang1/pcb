#include "m_BPP32_8R8G8B_Pattern.h"



// Zeichnet eine horizontale Linie 
int8 BPP32_8R8G8B_CHLine(int32 li32X1, int32 li32X2, int32 li32Y1, int32 li32Farbe, Screen* lpstScreen)
{
  int32 li32x;
  int32 li32i;

  if ((li32Y1 < 0) || (li32Y1 >= lpstScreen->ui16Height)) return 2;  
  
  if (li32X1 > li32X2)
  {
    li32x  = li32X2;
    li32X2 = li32X1;
    li32X1 = li32x;
  }

  if ((li32X2 < 0) || (li32X1 >= lpstScreen->ui16Width)) return 2;

  if (li32X1 < 0) li32X1 = 0;
  if (li32X2 >= lpstScreen->ui16Width) li32X2 = lpstScreen->ui16Width - 1;

  for (li32i = li32X1; li32i <= li32X2; li32i++) 
  {
    BPP32_8R8G8B_PXL(li32i,li32Y1,lpstScreen) = li32Farbe;
  }

  return 0;
}



//{Linienclipping mit Cohen - Sutherland} 
int32 BPP32_8R8G8B_LineclipY(int32 *li32LCX1, int32 *li32LCY1, 
                             int32 *li32LCX2, int32 *li32LCY2,
                             Screen* lpstScreen)
{
  int32  li32Done;
  int32  li32LineClip;
  int32  li32PCode,
         li32PCode1,
         li32PCode2;
  int32  li32LCX = 0,
         li32LCY = 0;
  int32  li32LCD;

  li32LineClip = false;
  li32Done     = false;
  li32PCode1   = 0;
  li32PCode2   = 0;

  //{BereichCodes}

  if (*li32LCY1 < 0) li32PCode1 = li32PCode1 | 8;
    else if (*li32LCY1 >= lpstScreen->ui16Height) li32PCode1 = li32PCode1 | 4;
  if (*li32LCY2 < 0) li32PCode2 = li32PCode2 | 8;
    else if (*li32LCY2 >= lpstScreen->ui16Height) li32PCode2 = li32PCode2 | 4;

  do
  {
    if ((li32PCode1 == 0) && (li32PCode2 == 0))
    {
      li32Done     = true;
      li32LineClip = true;
    }
    else if ((li32PCode1 & li32PCode2) != 0)
    {
      li32LineClip = false;
      li32Done     = true;
    }
    else
    {
      if (li32PCode1 != 0) li32PCode = li32PCode1;
      else li32PCode = li32PCode2;
      if ((li32PCode & 8) == 8)
      {
        // {ObenClip}
        li32LCD = *li32LCX2 - *li32LCX1;
        li32LCD = li32LCD * (0 - *li32LCY1);
        li32LCD = li32LCD  /  (*li32LCY2 - *li32LCY1);
        li32LCY = 0;
        li32LCX = *li32LCX1 + li32LCD;
      }
      else if ((li32PCode & 4) == 4)
      {
        //{UntenClip}
        li32LCD = (*li32LCX2 - *li32LCX1);
        li32LCD = li32LCD * (lpstScreen->ui16Height - 1 - *li32LCY1);
        li32LCD = li32LCD  /  (*li32LCY2 - *li32LCY1);
        li32LCY = lpstScreen->ui16Height - 1;
        li32LCX = *li32LCX1 + li32LCD;
      }

      if (li32PCode == li32PCode1)
      {
        li32PCode1 = 0;
        *li32LCX1   = li32LCX;
        *li32LCY1   = li32LCY;
        if (*li32LCY1 < 0) li32PCode1 = li32PCode1 | 8;
          else if (*li32LCY1 >= lpstScreen->ui16Height) li32PCode1 = li32PCode1 | 4;
      }
      else
      {
        li32PCode2 = 0;
        *li32LCX2   = li32LCX;
        *li32LCY2   = li32LCY;
        if (*li32LCY2 < 0) li32PCode2 = li32PCode2 | 8;
          else if (*li32LCY2 >= lpstScreen->ui16Height) li32PCode2 = li32PCode2 | 4;
      }
    }
  }
  while (!li32Done);

  return li32LineClip;
}


//{Linienclipping mit Cohen - Sutherland} 
int32 BPP32_8R8G8B_Lineclip(int32 *li32LCX1, int32 *li32LCY1, 
                            int32 *li32LCX2, int32 *li32LCY2,
                            Screen* lpstScreen)
{
  int32  li32Done;
  int32  li32LineClip;
  int32  li32PCode,
         li32PCode1,
         li32PCode2;
  int32  li32LCX = 0,
         li32LCY = 0;
  int32  li32LCD;

  li32LineClip = false;
  li32Done     = false;
  li32PCode1   = 0;
  li32PCode2   = 0;

  //{BereichCodes}

  if (*li32LCY1 < 0) li32PCode1 = li32PCode1 | 8;
    else if (*li32LCY1 >= lpstScreen->ui16Height) li32PCode1 = li32PCode1 | 4;
  if (*li32LCX1 < 0) li32PCode1 = li32PCode1 | 1;
    else if (*li32LCX1 >= lpstScreen->ui16Width)  li32PCode1 = li32PCode1 | 2;
  if (*li32LCY2 < 0) li32PCode2 = li32PCode2 | 8;
    else if (*li32LCY2 >= lpstScreen->ui16Height) li32PCode2 = li32PCode2 | 4;
  if (*li32LCX2 < 0) li32PCode2 = li32PCode2 | 1;
    else if (*li32LCX2 >= lpstScreen->ui16Width)  li32PCode2 = li32PCode2 | 2;

  do
  {
    if ((li32PCode1 == 0) && (li32PCode2 == 0))
    {
      li32Done     = true;
      li32LineClip = true;
    }
    else if ((li32PCode1 & li32PCode2) != 0)
    {
      li32LineClip = false;
      li32Done     = true;
    }
    else
    {
      if (li32PCode1 != 0) li32PCode = li32PCode1;
      else li32PCode = li32PCode2;
      if ((li32PCode & 8) == 8)
      {
        // {ObenClip}
        li32LCD = *li32LCX2 - *li32LCX1;
        li32LCD = li32LCD * (0 - *li32LCY1);
        li32LCD = li32LCD  /  (*li32LCY2 - *li32LCY1);
        li32LCY = 0;
        li32LCX = *li32LCX1 + li32LCD;
      }
      else if ((li32PCode & 4) == 4)
      {
        //{UntenClip}
        li32LCD = (*li32LCX2 - *li32LCX1);
        li32LCD = li32LCD * (lpstScreen->ui16Height - 1 - *li32LCY1);
        li32LCD = li32LCD  /  (*li32LCY2 - *li32LCY1);
        li32LCY = lpstScreen->ui16Height - 1;
        li32LCX = *li32LCX1 + li32LCD;
      }
      else if ((li32PCode & 2) == 2)
      {
        //{RechtsClip}
        li32LCD = (lpstScreen->ui16Width - 1 - *li32LCX1);
        li32LCD = li32LCD * (*li32LCY2 - *li32LCY1);
        li32LCD = li32LCD  /  (*li32LCX2 - *li32LCX1);
        li32LCX = lpstScreen->ui16Width - 1;
        li32LCY = *li32LCY1 + li32LCD;
      }
      else if ((li32PCode & 1) == 1)
      {
        //{LinksClip}
        li32LCD = 0 - *li32LCX1;
        li32LCD = li32LCD * (*li32LCY2 - *li32LCY1);
        li32LCD = li32LCD  /  (*li32LCX2 - *li32LCX1);
        li32LCX = 0;
        li32LCY = *li32LCY1 + li32LCD;
      }
      if (li32PCode == li32PCode1)
      {
        li32PCode1 = 0;
        *li32LCX1   = li32LCX;
        *li32LCY1   = li32LCY;
        if (*li32LCY1 < 0) li32PCode1 = li32PCode1 | 8;
          else if (*li32LCY1 >= lpstScreen->ui16Height) li32PCode1 = li32PCode1 | 4;
        if (*li32LCX1 < 0) li32PCode1 = li32PCode1 | 1;
          else if (*li32LCX1 >= lpstScreen->ui16Width) li32PCode1 = li32PCode1 | 2;
      }
      else
      {
        li32PCode2 = 0;
        *li32LCX2   = li32LCX;
        *li32LCY2   = li32LCY;
        if (*li32LCY2 < 0) li32PCode2 = li32PCode2 | 8;
          else if (*li32LCY2 >= lpstScreen->ui16Height) li32PCode2 = li32PCode2 | 4;
        if (*li32LCX2 < 0) li32PCode2 = li32PCode2 | 1;
          else if (*li32LCX2 >= lpstScreen->ui16Width) li32PCode2 = li32PCode2 | 2;
      }
    }
  }
  while (!li32Done);

  return li32LineClip;
}

// Zeichnet eine Linie auf Seite1
int8 BPP32_8R8G8B_CLine(int32 li32X1, int32 li32Y1, 
                        int32 li32X2, int32 li32Y2,
                        int32 li32Farbe, Screen* lpstScreen)

{
  int32 li32Xd, li32Dx, li32Dy;
  int32 li32AIncr, li32BIncr;
  int32 li32XIncr, li32YIncr;
  int32 li32x, li32y , li32Dummy;

  if (!BPP32_8R8G8B_Lineclip(&li32X1, &li32Y1, &li32X2, &li32Y2, lpstScreen)) return 2;

  if ((abs(li32X2 - li32X1) < abs(li32Y2 - li32Y1)))
  {
    if (li32Y1 > li32Y2)
    {
      li32Dummy = li32X1;
      li32X1    = li32X2;
      li32X2    = li32Dummy;
      li32Dummy = li32Y1;
      li32Y1    = li32Y2;
      li32Y2    = li32Dummy;
    }

    if (li32X2 > li32X1) li32XIncr = 1;
	                  else li32XIncr = -1;

    li32Dy    = li32Y2 - li32Y1;
    li32Dx    = abs(li32X2 - li32X1);
    li32Xd    = 2 * li32Dx - li32Dy;
    li32AIncr = 2 * (li32Dx - li32Dy);
    li32BIncr = 2 * li32Dx;
    li32x     = li32X1;
    li32y     = li32Y1;

    BPP32_8R8G8B_PXL(li32x, li32y, lpstScreen) = li32Farbe;

    for (li32y = li32Y1 + 1;li32y <= li32Y2;li32y++)
    {
      if (li32Xd >= 0)
      {
        li32x  += li32XIncr;
        li32Xd += li32AIncr;
      }
      else li32Xd += li32BIncr;

      BPP32_8R8G8B_PXL(li32x, li32y, lpstScreen) = li32Farbe;
    }
  }
  else
  {
    if (li32X1 > li32X2)
    {
      li32Dummy = li32X1;
      li32X1    = li32X2;
      li32X2    = li32Dummy;
      li32Dummy = li32Y1;
      li32Y1    = li32Y2;
      li32Y2    = li32Dummy;
    }
    if (li32Y2 > li32Y1) li32YIncr = 1;
                    else li32YIncr = -1;

    li32Dx    = li32X2 - li32X1;
    li32Dy    = abs(li32Y2 - li32Y1);
    li32Xd    = 2 * li32Dy - li32Dx;
    li32AIncr = 2 * (li32Dy - li32Dx);
    li32BIncr = 2 * li32Dy;
    li32x     = li32X1;
    li32y     = li32Y1;

    BPP32_8R8G8B_PXL(li32x, li32y, lpstScreen) = li32Farbe;

    for (li32x = li32X1 + 1;li32x <= li32X2;li32x++)
    {
      if (li32Xd >= 0)
      {
        li32y  += li32YIncr;
        li32Xd += li32AIncr;
      }
      else li32Xd += li32BIncr;

      BPP32_8R8G8B_PXL(li32x, li32y, lpstScreen) = li32Farbe;
    }
  }

    return 0;
}


int8 BPP32_8R8G8B_CMemLine(int32 li32X1, int32 li32Y1, 
                           int32 li32X2, int32 li32Y2,
                           int32 lpi32Speicher[],
                           Screen* lpstScreen)
{

  int32 li32Xd, li32Dx, li32Dy;
  int32 li32AIncr, li32BIncr;
  int32 li32XIncr, li32YIncr;
  int32 li32x, li32y , li32Dummy;

  if (!BPP32_8R8G8B_Lineclip(&li32X1, &li32Y1, &li32X2, &li32Y2, lpstScreen)) return 2;

  if ((abs(li32X2 - li32X1) < abs(li32Y2 - li32Y1)))
  {
    if (li32Y1 > li32Y2)
    {
      li32Dummy = li32X1;
      li32X1    = li32X2;
      li32X2    = li32Dummy;
      li32Dummy = li32Y1;
      li32Y1    = li32Y2;
      li32Y2    = li32Dummy;
    }
    if (li32X2 > li32X1) li32XIncr = 1;
	                  else li32XIncr = -1;

    li32Dy    = li32Y2 - li32Y1;
    li32Dx    = abs(li32X2 - li32X1);
    li32Xd    = 2 * li32Dx - li32Dy;
    li32AIncr = 2 * (li32Dx - li32Dy);
    li32BIncr = 2 * li32Dx;
    li32x     = li32X1;
    li32y     = li32Y1;
    lpi32Speicher[li32y] = li32x;

    for (li32y = li32Y1 + 1;li32y <= li32Y2;li32y++)
    {
      if (li32Xd >= 0)
      {
        li32x += li32XIncr;
        li32Xd += li32AIncr;
      }
      else li32Xd += li32BIncr;

      lpi32Speicher[li32y] = li32x;
    }
  }
  else
  {
    if (li32X1 > li32X2)
    {
      li32Dummy = li32X1;
      li32X1    = li32X2;
      li32X2    = li32Dummy;
      li32Dummy = li32Y1;
      li32Y1    = li32Y2;
      li32Y2    = li32Dummy;
    }
    if (li32Y2 > li32Y1) li32YIncr = 1;
	                  else li32YIncr = -1;
    li32Dx    = li32X2 - li32X1;
    li32Dy    = abs(li32Y2 - li32Y1);
    li32Xd    = 2 * li32Dy - li32Dx;
    li32AIncr = 2 * (li32Dy - li32Dx);
    li32BIncr = 2 * li32Dy;
    li32x     = li32X1;
    li32y     = li32Y1;
    lpi32Speicher[li32y] = li32x;

    for (li32x = li32X1 + 1;li32x <= li32X2;li32x++)
    {
      if (li32Xd >= 0)
      {
        li32y  += li32YIncr;
        li32Xd += li32AIncr;
      }
      else li32Xd += li32BIncr;

      lpi32Speicher[li32y] = li32x;
    }
  }

  return 0;
}


int8 BPP32_8R8G8B_CYMemLine(int32 li32X1, int32 li32Y1, 
                            int32 li32X2, int32 li32Y2,
                            int32 lpi32Speicher[],
                            Screen* lpstScreen)
{

  int32 li32Xd, li32Dx, li32Dy;
  int32 li32AIncr, li32BIncr;
  int32 li32XIncr, li32YIncr;
  int32 li32x, li32y , li32Dummy;

  if (!BPP32_8R8G8B_LineclipY(&li32X1, &li32Y1, &li32X2, &li32Y2, lpstScreen)) return 2;

  if ((abs(li32X2 - li32X1) < abs(li32Y2 - li32Y1)))
  {
    if (li32Y1 > li32Y2)
    {
      li32Dummy = li32X1;
      li32X1    = li32X2;
      li32X2    = li32Dummy;
      li32Dummy = li32Y1;
      li32Y1    = li32Y2;
      li32Y2    = li32Dummy;
    }
    if (li32X2 > li32X1) li32XIncr = 1;
	                  else li32XIncr = -1;

    li32Dy    = li32Y2 - li32Y1;
    li32Dx    = abs(li32X2 - li32X1);
    li32Xd    = 2 * li32Dx - li32Dy;
    li32AIncr = 2 * (li32Dx - li32Dy);
    li32BIncr = 2 * li32Dx;
    li32x     = li32X1;
    li32y     = li32Y1;
    lpi32Speicher[li32y] = li32x;

    for (li32y = li32Y1 + 1;li32y <= li32Y2;li32y++)
    {
      if (li32Xd >= 0)
      {
        li32x += li32XIncr;
        li32Xd += li32AIncr;
      }
      else li32Xd += li32BIncr;

      lpi32Speicher[li32y] = li32x;
    }
  }
  else
  {
    if (li32X1 > li32X2)
    {
      li32Dummy = li32X1;
      li32X1    = li32X2;
      li32X2    = li32Dummy;
      li32Dummy = li32Y1;
      li32Y1    = li32Y2;
      li32Y2    = li32Dummy;
    }
    if (li32Y2 > li32Y1) li32YIncr = 1;
	                  else li32YIncr = -1;
    li32Dx    = li32X2 - li32X1;
    li32Dy    = abs(li32Y2 - li32Y1);
    li32Xd    = 2 * li32Dy - li32Dx;
    li32AIncr = 2 * (li32Dy - li32Dx);
    li32BIncr = 2 * li32Dy;
    li32x     = li32X1;
    li32y     = li32Y1;
    lpi32Speicher[li32y] = li32x;

    for (li32x = li32X1 + 1;li32x <= li32X2;li32x++)
    {
      if (li32Xd >= 0)
      {
        li32y  += li32YIncr;
        li32Xd += li32AIncr;
      }
      else li32Xd += li32BIncr;

      lpi32Speicher[li32y] = li32x;
    }
  }

  return 0;
}


// Zeichnet ein Viereck auf Schirm
int8 BPP32_8R8G8B_ZeichneViereck(int32 li32x, int32 li32y, int32 li32Width, int32 li32Heigth, int32 li32Col, Screen* lpstScreen)
{
  BPP32_8R8G8B_CLine(li32x,            li32y,              li32x + li32Width, li32y,              li32Col, lpstScreen);
  BPP32_8R8G8B_CLine(li32x,            li32y + li32Heigth, li32x + li32Width, li32y + li32Heigth, li32Col, lpstScreen);
  BPP32_8R8G8B_CLine(li32x + li32Width,li32y + li32Heigth, li32x + li32Width, li32y,              li32Col, lpstScreen);
  BPP32_8R8G8B_CLine(li32x,            li32y,              li32x,             li32y + li32Heigth, li32Col, lpstScreen);

  return 0;
}

// Zeichnet ein ausgef�lltet Viereck auf Schirm
int8 BPP32_8R8G8B_ZeichneViereckVoll(int32 li32x, int32 li32y, int32 li32Width, int32 li32Heigth, int32 li32Col, Screen* lpstScreen)
{
  int32 li32i;
  for (li32i = li32y; (li32i - li32y) <= li32Heigth; li32i++) 
    BPP32_8R8G8B_CHLine(li32x, (li32x + li32Width), li32i, li32Col, lpstScreen);

  return 0;
}

// Zeichnet ein gleichschenkliges Dreieck auf Schirm
int8 BPP32_8R8G8B_ZeichneDreieck(int32 li32x, int32 li32y, int32 li32Lenght, int32 li32Wink, int32 li32Col, Screen* lpstScreen)
{
  int32 li32x1, li32y1, 
        li32x2, li32y2,
        li32x3, li32y3;

  li32x1 = li32x + (int32)(cos((  0 + li32Wink) * SCREEN_PI / 180.0f) * (float)li32Lenght);
  li32y1 = li32y + (int32)(sin((  0 + li32Wink) * SCREEN_PI / 180.0f) * (float)li32Lenght);
  li32x2 = li32x + (int32)(cos((120 + li32Wink) * SCREEN_PI / 180.0f) * (float)li32Lenght);
  li32y2 = li32y + (int32)(sin((120 + li32Wink) * SCREEN_PI / 180.0f) * (float)li32Lenght);
  li32x3 = li32x + (int32)(cos((240 + li32Wink) * SCREEN_PI / 180.0f) * (float)li32Lenght);
  li32y3 = li32y + (int32)(sin((240 + li32Wink) * SCREEN_PI / 180.0f) * (float)li32Lenght);
 
  BPP32_8R8G8B_CLine(li32x1, li32y1, li32x2, li32y2, li32Col, lpstScreen);
  BPP32_8R8G8B_CLine(li32x2, li32y2, li32x3, li32y3, li32Col, lpstScreen);
  BPP32_8R8G8B_CLine(li32x3, li32y3, li32x1, li32y1, li32Col, lpstScreen);

  return 0;
}



// Zeichnet ein ausgef�lltes gleichschenkliges Dreieck auf Schirm
int8 BPP32_8R8G8B_ZeichneDreieckVoll(int32 li32x, int32 li32y, int32 li32Lenght, int32 li32Wink, int32 li32Col, Screen* lpstScreen)

{
  int32 li32x1, li32y1,
        li32x2, li32y2,
        li32x3, li32y3;

  int32 li32MinY;
  int32 li32MaxY;
  int32 li32MinYL;
  int32 li32MaxYL;
  int32 li32i;

  int32* lpi32Linie1;
  int32* lpi32Linie2;
  int32* lpi32Linie3;

  lpi32Linie1 = (int32*)malloc(lpstScreen->ui16Height * sizeof(int32*));
  lpi32Linie2 = (int32*)malloc(lpstScreen->ui16Height * sizeof(int32*));
  lpi32Linie3 = (int32*)malloc(lpstScreen->ui16Height * sizeof(int32*));

  memset(lpi32Linie1, -1, lpstScreen->ui16Height);
  memset(lpi32Linie2, -1, lpstScreen->ui16Height);
  memset(lpi32Linie3, -1, lpstScreen->ui16Height);

  li32Wink = li32Wink % 120;

  li32x1 = li32x + (int32)(cos((  0 + li32Wink) * SCREEN_PI / 180.0f) * (float)li32Lenght);
  li32y1 = li32y + (int32)(sin((  0 + li32Wink) * SCREEN_PI / 180.0f) * (float)li32Lenght);
  li32x2 = li32x + (int32)(cos((120 + li32Wink) * SCREEN_PI / 180.0f) * (float)li32Lenght);
  li32y2 = li32y + (int32)(sin((120 + li32Wink) * SCREEN_PI / 180.0f) * (float)li32Lenght);
  li32x3 = li32x + (int32)(cos((240 + li32Wink) * SCREEN_PI / 180.0f) * (float)li32Lenght);
  li32y3 = li32y + (int32)(sin((240 + li32Wink) * SCREEN_PI / 180.0f) * (float)li32Lenght);

  BPP32_8R8G8B_CYMemLine(li32x1, li32y1, li32x2, li32y2, lpi32Linie1, lpstScreen);
  BPP32_8R8G8B_CYMemLine(li32x2, li32y2, li32x3, li32y3, lpi32Linie2, lpstScreen);
  BPP32_8R8G8B_CYMemLine(li32x3, li32y3, li32x1, li32y1, lpi32Linie3, lpstScreen);

  li32MinY = li32y3;
  if (li32y2 < li32MinY) li32MinY = li32y2;
  if (li32y1 < li32MinY) li32MinY = li32y1;

  li32MaxY = li32y3;
  if (li32y2 > li32MaxY) li32MaxY = li32y2;
  if (li32y1 > li32MaxY) li32MaxY = li32y1;

  if (li32MaxY > lpstScreen->ui16Height - 1) li32MaxY = lpstScreen->ui16Height - 1;
  if (li32MinY < 0) li32MinY = 0;

  li32MinY = li32y3;
  if (li32y2 < li32MinY) li32MinY = li32y2;
  if (li32y1 < li32MinY) li32MinY = li32y1;

  li32MaxY = li32y3;
  if (li32y2 > li32MaxY) li32MaxY = li32y2;
  if (li32y1 > li32MaxY) li32MaxY = li32y1;

  if (li32MaxY >= lpstScreen->ui16Height) li32MaxY = lpstScreen->ui16Height - 1;
  if (li32MinY < 0) li32MinY = 0;


  if (li32y1 < li32y2) 
  {
    li32MinYL = li32y1; 
    li32MaxYL = li32y2;
  }
  else
  {
    li32MinYL = li32y2; 
    li32MaxYL = li32y1;
  }

  if (li32MinYL < li32MinY) li32MinYL = li32MinY;
  if (li32MaxYL > li32MaxY) li32MaxYL = li32MaxY;

  for (li32i = li32MinYL; li32i <= li32MaxYL; li32i++)
  {
    if (li32i>0) if (lpi32Linie1[li32i] < 0) lpi32Linie1[li32i] = 0 ;
  }

  if (li32y2 < li32y3) 
  {
    li32MinYL = li32y2; 
    li32MaxYL = li32y3;
  }
  else
  {
    li32MinYL = li32y3; 
    li32MaxYL = li32y2;
  }

  if (li32MinYL < li32MinY) li32MinYL = li32MinY;
  if (li32MaxYL > li32MaxY) li32MaxYL = li32MaxY;

  for (li32i = li32MinYL; li32i <= li32MaxYL; li32i++)
  {
    if (lpi32Linie2[li32i] < 0) lpi32Linie2[li32i] = 0 ;
  }

  if (li32y3 < li32y1) 
  {
    li32MinYL = li32y3; 
    li32MaxYL = li32y1;
  }
  else
  {
    li32MinYL = li32y1; 
    li32MaxYL = li32y3;
  }

  if (li32MinYL < li32MinY) li32MinYL = li32MinY;
  if (li32MaxYL > li32MaxY) li32MaxYL = li32MaxY;

  for (li32i = li32MinYL; li32i <= li32MaxYL; li32i++)
  {
    if (lpi32Linie3[li32i] < 0) lpi32Linie3[li32i] = 0 ;
  }



  for (li32i = li32MinY; li32i <= li32MaxY; li32i++)
  {
    if ((lpi32Linie1[li32i] >= 0)  && (lpi32Linie2[li32i] >= 0) &&
	      (lpi32Linie1[li32i] != lpi32Linie2[li32i]))                BPP32_8R8G8B_CHLine(lpi32Linie1[li32i], lpi32Linie2[li32i], li32i, li32Col, lpstScreen);
    if ((lpi32Linie1[li32i] >= 0)  && (lpi32Linie3[li32i] >= 0) &&
	      (lpi32Linie1[li32i] != lpi32Linie3[li32i]))                BPP32_8R8G8B_CHLine(lpi32Linie1[li32i], lpi32Linie3[li32i], li32i, li32Col, lpstScreen);
    if ((lpi32Linie2[li32i] >= 0)  && (lpi32Linie3[li32i] >= 0) &&
	      (lpi32Linie2[li32i] != lpi32Linie3[li32i]))                BPP32_8R8G8B_CHLine(lpi32Linie2[li32i], lpi32Linie3[li32i], li32i, li32Col, lpstScreen);
  }

  free(lpi32Linie1);
  free(lpi32Linie2);
  free(lpi32Linie3);

  return 0;
}


// Zeichnet ein ausgef�lltes Quadrat auf Schirm
int8 BPP32_8R8G8B_ZeichneQuadratVoll(int32 li32x, int32 li32y, int32 li32Lenght, int32 li32Wink, int32 li32Col, Screen* lpstScreen)

{
  int32 li32x1, li32y1,
        li32x2, li32y2,
        li32x3, li32y3,
        li32x4, li32y4;
  int32 li32MinY;
  int32 li32MaxY;
  int32 li32MinYL;
  int32 li32MaxYL;
  int32 li32i;


  int32* lpi32Linie1;
  int32* lpi32Linie2;
  int32* lpi32Linie3;
  int32* lpi32Linie4;

  lpi32Linie1 = (int32*)malloc(lpstScreen->ui16Height * sizeof(int32*));
  lpi32Linie2 = (int32*)malloc(lpstScreen->ui16Height * sizeof(int32*));
  lpi32Linie3 = (int32*)malloc(lpstScreen->ui16Height * sizeof(int32*));
  lpi32Linie4 = (int32*)malloc(lpstScreen->ui16Height * sizeof(int32*));


  memset(lpi32Linie1, -1, lpstScreen->ui16Height);
  memset(lpi32Linie2, -1, lpstScreen->ui16Height);
  memset(lpi32Linie3, -1, lpstScreen->ui16Height);
  memset(lpi32Linie4, -1, lpstScreen->ui16Height);

  // li32Wink = li32Wink - (li32Wink % 5);

  li32x1 = li32x + (int32)(cos((  0 + li32Wink) * SCREEN_PI / 180.0f) * (float)li32Lenght);
  li32y1 = li32y + (int32)(sin((  0 + li32Wink) * SCREEN_PI / 180.0f) * (float)li32Lenght);
  li32x2 = li32x + (int32)(cos(( 90 + li32Wink) * SCREEN_PI / 180.0f) * (float)li32Lenght);
  li32y2 = li32y + (int32)(sin(( 90 + li32Wink) * SCREEN_PI / 180.0f) * (float)li32Lenght);
  li32x3 = li32x + (int32)(cos((180 + li32Wink) * SCREEN_PI / 180.0f) * (float)li32Lenght);
  li32y3 = li32y + (int32)(sin((180 + li32Wink) * SCREEN_PI / 180.0f) * (float)li32Lenght);
  li32x4 = li32x + (int32)(cos((270 + li32Wink) * SCREEN_PI / 180.0f) * (float)li32Lenght);
  li32y4 = li32y + (int32)(sin((270 + li32Wink) * SCREEN_PI / 180.0f) * (float)li32Lenght);

  BPP32_8R8G8B_CYMemLine(li32x1, li32y1, li32x2, li32y2, lpi32Linie1, lpstScreen);
  BPP32_8R8G8B_CYMemLine(li32x2, li32y2, li32x3, li32y3, lpi32Linie2, lpstScreen);
  BPP32_8R8G8B_CYMemLine(li32x3, li32y3, li32x4, li32y4, lpi32Linie3, lpstScreen);
  BPP32_8R8G8B_CYMemLine(li32x4, li32y4, li32x1, li32y1, lpi32Linie4, lpstScreen);

  li32MinY = li32y4;
  if (li32y3 < li32MinY) li32MinY = li32y3;
  if (li32y2 < li32MinY) li32MinY = li32y2;
  if (li32y1 < li32MinY) li32MinY = li32y1;

  li32MaxY = li32y4;
  if (li32y3 > li32MaxY) li32MaxY = li32y3;
  if (li32y2 > li32MaxY) li32MaxY = li32y2;
  if (li32y1 > li32MaxY) li32MaxY = li32y1;

  if (li32MaxY >= lpstScreen->ui16Height) li32MaxY = lpstScreen->ui16Height - 1;
  if (li32MinY < 0) li32MinY = 0;


  if (li32y1 < li32y2) 
  {
    li32MinYL = li32y1; 
    li32MaxYL = li32y2;
  }
  else
  {
    li32MinYL = li32y2; 
    li32MaxYL = li32y1;
  }

  if (li32MinYL < li32MinY) li32MinYL = li32MinY;
  if (li32MaxYL > li32MaxY) li32MaxYL = li32MaxY;

  for (li32i = li32MinYL; li32i <= li32MaxYL; li32i++)
  {
    if (li32i>0) if (lpi32Linie1[li32i] < 0) lpi32Linie1[li32i] = 0 ;
  }

  if (li32y2 < li32y3) 
  {
    li32MinYL = li32y2; 
    li32MaxYL = li32y3;
  }
  else
  {
    li32MinYL = li32y3; 
    li32MaxYL = li32y2;
  }

  if (li32MinYL < li32MinY) li32MinYL = li32MinY;
  if (li32MaxYL > li32MaxY) li32MaxYL = li32MaxY;

  for (li32i = li32MinYL; li32i <= li32MaxYL; li32i++)
  {
    if (lpi32Linie2[li32i] < 0) lpi32Linie2[li32i] = 0 ;
  }

  if (li32y3 < li32y4) 
  {
    li32MinYL = li32y3; 
    li32MaxYL = li32y4;
  }
  else
  {
    li32MinYL = li32y4; 
    li32MaxYL = li32y3;
  }

  if (li32MinYL < li32MinY) li32MinYL = li32MinY;
  if (li32MaxYL > li32MaxY) li32MaxYL = li32MaxY;

  for (li32i = li32MinYL; li32i <= li32MaxYL; li32i++)
  {
    if (lpi32Linie3[li32i] < 0) lpi32Linie3[li32i] = 0 ;
  }

  if (li32y4 < li32y1) 
  {
    li32MinYL = li32y4; 
    li32MaxYL = li32y1;
  }
  else
  {
    li32MinYL = li32y1; 
    li32MaxYL = li32y4;
  }

  if (li32MinYL < li32MinY) li32MinYL = li32MinY;
  if (li32MaxYL > li32MaxY) li32MaxYL = li32MaxY;

  for (li32i = li32MinYL; li32i <= li32MaxYL; li32i++)
  {
    if (lpi32Linie4[li32i] < 0) lpi32Linie4[li32i] = 0 ;
  }



  for (li32i = li32MinY; li32i <= li32MaxY; li32i++)
  {
    if ((lpi32Linie1[li32i] >= 0)  && (lpi32Linie2[li32i] >= 0) &&
	      (lpi32Linie1[li32i] != lpi32Linie2[li32i]))                BPP32_8R8G8B_CHLine(lpi32Linie1[li32i], lpi32Linie2[li32i], li32i, li32Col, lpstScreen);
    if ((lpi32Linie1[li32i] >= 0)  && (lpi32Linie3[li32i] >= 0) &&
	      (lpi32Linie1[li32i] != lpi32Linie3[li32i]))                BPP32_8R8G8B_CHLine(lpi32Linie1[li32i], lpi32Linie3[li32i], li32i, li32Col, lpstScreen);
    if ((lpi32Linie1[li32i] >= 0)  && (lpi32Linie4[li32i] >= 0) &&
	      (lpi32Linie1[li32i] != lpi32Linie4[li32i]))                BPP32_8R8G8B_CHLine(lpi32Linie1[li32i], lpi32Linie4[li32i], li32i, li32Col, lpstScreen);
    if ((lpi32Linie2[li32i] >= 0)  && (lpi32Linie3[li32i] >= 0) &&
	      (lpi32Linie2[li32i] != lpi32Linie3[li32i]))                BPP32_8R8G8B_CHLine(lpi32Linie2[li32i], lpi32Linie3[li32i], li32i, li32Col, lpstScreen);
    if ((lpi32Linie2[li32i] >= 0)  && (lpi32Linie4[li32i] >= 0) &&
	      (lpi32Linie2[li32i] != lpi32Linie4[li32i]))                BPP32_8R8G8B_CHLine(lpi32Linie2[li32i], lpi32Linie4[li32i], li32i, li32Col, lpstScreen);
    if ((lpi32Linie3[li32i] >= 0)  && (lpi32Linie4[li32i] >= 0) &&
  	    (lpi32Linie3[li32i] != lpi32Linie4[li32i]))                BPP32_8R8G8B_CHLine(lpi32Linie3[li32i], lpi32Linie4[li32i], li32i, li32Col, lpstScreen);
  }

  free(lpi32Linie1);
  free(lpi32Linie2);
  free(lpi32Linie3);
  free(lpi32Linie4);

  return 0;
}

// Zeichnet ein ausgef�lltes Kreis auf Schirm
int8 BPP32_8R8G8B_ZeichneKreis(int32 li32x1, int32 li32y1, int32 li32Radius, int32 li32Col, Screen* lpstScreen)
{
  int32 li32x;
  int32 li32i;
  for (li32i = -li32Radius; li32i <= li32Radius; li32i++)
  {
    li32x = (int32)(sqrt((float)(li32Radius * li32Radius - li32i * li32i) + 0.5));
    BPP32_8R8G8B_SetPixel((li32x1 + li32x), (li32i + li32y1), li32Col, lpstScreen);
    BPP32_8R8G8B_SetPixel((li32x1 - li32x), (li32i + li32y1), li32Col, lpstScreen);
  }

  for (li32i = -li32Radius; li32i <= li32Radius; li32i++)
  {
    li32x = (int32)(sqrt((float)(li32Radius * li32Radius - li32i * li32i) + 0.5));
    BPP32_8R8G8B_SetPixel((li32i + li32y1), (li32x1 + li32x), li32Col, lpstScreen);
    BPP32_8R8G8B_SetPixel((li32i + li32y1), (li32x1 - li32x), li32Col, lpstScreen);
  }

  return 0;
}

// Zeichnet ein ausgef�lltes Kreis auf Schirm
int8 BPP32_8R8G8B_ZeichneKreisVoll(int32 li32x1, int32 li32y1, int32 li32Radius, int32 li32Col, Screen* lpstScreen)
{
  int32 li32x;
  int32 li32i; 

  for (li32i = -li32Radius; li32i <= li32Radius; li32i++)
  {
    li32x = (int32)(sqrt((float)(li32Radius * li32Radius - li32i * li32i) + 0.5));
    BPP32_8R8G8B_CHLine((li32x1 + li32x), (li32x1 - li32x), (li32i + li32y1), li32Col, lpstScreen);
  }
  return 0;
}


