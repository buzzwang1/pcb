#ifndef _M_BPP32_8R8G8B_PATTERN
#define _M_BPP32_8R8G8B_PATTERN

#include <stdlib.h>      
#include <stdio.h>
#include <math.h>


#include "_TypeDef.h"
#include "m_Screen.h"
#include "m_BPP32_8R8G8B_Tools.h"
#include "m_BPP32_8R8G8B_Pattern.h"


extern int8 BPP32_8R8G8B_CHLine(int32 li32X1, int32 li32X2, int32 li32Y1, int32 li32Farbe, Screen* lpstScreen);
         
extern int32 BPP32_8R8G8B_Lineclip(int32 *li32LCX1, int32 *li32LCY1, 
                                   int32 *li32LCX2, int32 *li32LCY2,
                                   Screen* lpstScreen);

extern int8 BPP32_8R8G8B_CLine(int32 li32X1, int32 li32Y1, 
                               int32 li32X2, int32 li32Y2,
                               int32 li32Farbe, Screen* lpstScreen);

extern int8 BPP32_8R8G8B_CMemLine(int32 li32X1, int32 li32Y1, 
                                  int32 li32X2, int32 li32Y2,
                                  int32 lpi32Speicher[],
                                  Screen* lpstScreen);

extern int8 BPP32_8R8G8B_ZeichneViereck(int32 li32x, int32 li32y, int32 li32Width, int32 li32Heigth, int32 li32Col, Screen* lpstScreen);
extern int8 BPP32_8R8G8B_ZeichneViereckVoll(int32 li32x, int32 li32y, int32 li32Width, int32 li32Heigth, int32 li32Col, Screen* lpstScreen);
extern int8 BPP32_8R8G8B_ZeichneDreieck(int32 li32x, int32 li32y, int32 li32Lenght, int32 li32Wink, int32 li32Col, Screen* lpstScreen);
extern int8 BPP32_8R8G8B_ZeichneDreieckVoll(int32 li32x, int32 li32y, int32 li32Lenght, int32 li32Wink, int32 li32Col, Screen* lpstScreen);
extern int8 BPP32_8R8G8B_ZeichneQuadratVoll(int32 li32x, int32 li32y, int32 li32Lenght, int32 li32Wink, int32 li32Col, Screen* lpstScreen);
extern int8 BPP32_8R8G8B_ZeichneKreis(int32 li32x1, int32 li32y1, int32 li32Radius, int32 li32Col, Screen* lpstScreen);
extern int8 BPP32_8R8G8B_ZeichneKreisVoll(int32 li32x1, int32 li32y1, int32 li32Radius, int32 li32Col, Screen* lpstScreen);



#endif

