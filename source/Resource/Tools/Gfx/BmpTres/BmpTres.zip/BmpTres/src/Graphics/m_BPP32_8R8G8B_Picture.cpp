#include "m_BPP32_8R8G8B_Picture.h"


int8 BPP32_8R8G8B_TGALoad(char *szFilename, Screen *lpstDestScreen)
{

	uint8		   lui8BPP;           // Bits Per Pixel
	uint8     *pui8Buffer;
	uint32     ui32BitSize;		    // Total lui32Size of bitmap

	int32	     li32t;
  
  FILE	    *lpFile;
  int16      lui16Width, lui16Height;
	TGAHeader  lpstTGAHeader;
  unRGB32    lunRGB32;
  Screen     lstTempScreen;

  // Open the file and read the lstBMP_Header
	lpFile = fopen(szFilename, "rb");

  if (lpFile == null) return 2;

  if (fread(&lpstTGAHeader, sizeof(TGAHeader), 1, lpFile) != 1 )
  {
      fclose(lpFile);
      return 1;
  }

	lui16Width  = lpstTGAHeader.ui8Width;
	lui16Height = lpstTGAHeader.ui8Height;
	lui8BPP     = lpstTGAHeader.ui8PixelSize;          // 16, 24, or 32
  ui32BitSize = lui16Width * lui16Height * (lui8BPP / 8);


  // Create a bitmap to load the data into
	if (ScreenInit(lpstDestScreen) != 0)
	{
        fclose(lpFile);
        return 1;
	}

	if (ScreenCreate(BPP32_8R8G8B, lui16Width, lui16Height, lpstDestScreen) != 0)
	{
        fclose(lpFile);
        return 1;
	}
 

 	pui8Buffer = (uint8*)malloc(ui32BitSize);

  if (fread(pui8Buffer, ui32BitSize, 1, lpFile) != 1 )
	{
    fclose(lpFile);
		free(pui8Buffer);
    return 1;
	}

  fclose(lpFile);

  ScreenInit(&lstTempScreen);
  SCREEN_CLONE(lpstDestScreen, (&lstTempScreen));

  switch (lui8BPP)
  {
    case 16:
		  for (li32t = 0; li32t < SCREEN_SIZE((&lstTempScreen)); li32t++)
		  {
	      lunRGB32.stRGB32.ui8B =  (((uint16*) pui8Buffer)[li32t] >> 10);
        lunRGB32.stRGB32.ui8G = ((((uint16*) pui8Buffer)[li32t] >> 5) & 0x1f);
        lunRGB32.stRGB32.ui8R =  (((uint16*) pui8Buffer)[li32t]  & 0x1f);

        BPP32_8R8G8B_MEM(li32t, (&lstTempScreen)) = lunRGB32.ui32RGB32;
		  }

      free(pui8Buffer);      
    break;
    case 24:
		  for (li32t = 0; li32t < SCREEN_SIZE((&lstTempScreen)); li32t++)
		  {

	      lunRGB32.stRGB32.ui8B = pui8Buffer[li32t * 3 + 2];
        lunRGB32.stRGB32.ui8G = pui8Buffer[li32t * 3 + 1];
        lunRGB32.stRGB32.ui8R = pui8Buffer[li32t * 3 + 0];

        BPP32_8R8G8B_MEM(li32t, (&lstTempScreen)) = lunRGB32.ui32RGB32;
		  }

      free(pui8Buffer);
    break;
    case 32:
      free((&lstTempScreen)->paui8Screen);
      (&lstTempScreen)->paui8Screen = pui8Buffer;
    break;

    default:
      free(pui8Buffer);
      return 1;
  }

  BPP32_8R8G8B_ScreenFlipY(&lstTempScreen, lpstDestScreen);

  ScreenDelete(&lstTempScreen);

  return 0;
}



int8 BPP32_8R8G8B_BMPLoad(char *szFilename, Screen *lpstDestScreen)
{
  FILE             *lpFile;
  uint8            *lpui8Bits;
  uint32            lui32BitSize;
  uint32            lui32InfoSize;
  BITMAPFILEHEADER  lstBMP_Header;
  BITMAPINFO       *lstBMP_Info;
  int8              li8Fehler;


  li8Fehler = 0;

  // Versuchen Datei zu �ffnen
  if ((lpFile = fopen(szFilename, "rb")) != NULL)
  {

    // Datei Header mit Bitmap Informationen lesen
    if (fread(&lstBMP_Header, sizeof(BITMAPFILEHEADER), 1, lpFile) < 1)
    {
      // Konnte Header nicht lesen
	    li8Fehler = 1;
    }

    if (!li8Fehler)
    {
      // BM Identifier �berpr�fen
      if (lstBMP_Header.bfType != 'MB')	
      {
        li8Fehler = 1;
      }
    }

    if (!li8Fehler)
    {
      lui32InfoSize = lstBMP_Header.bfOffBits - sizeof(BITMAPFILEHEADER);
      if ((lstBMP_Info = (BITMAPINFO *)malloc(lui32InfoSize)) == NULL)
      {
        // Nicht genug Speicher f�r BITMAPINFO
        li8Fehler = 1;
      }
    }

    if (!li8Fehler)
    {
      if (fread(lstBMP_Info, 1, lui32InfoSize, lpFile) < lui32InfoSize)
      {
        // Konnte Header nicht lesen
        free(lstBMP_Info);
        li8Fehler = 1;
      }
    }


    //Speicher f�r Bilddaten holen
    if (!li8Fehler)
    {
      if ((lui32BitSize = lstBMP_Info->bmiHeader.biSizeImage) == 0)
      {
        int32 li32Width;

        switch (lstBMP_Info->bmiHeader.biBitCount)
        {
          case 1:
            li32Width = ((lstBMP_Info->bmiHeader.biWidth / 8) % 4);
            if (li32Width) li32Width = 4 - li32Width;
            li32Width += (lstBMP_Info->bmiHeader.biWidth / 8);
          break;

          case 4:
            li32Width = ((lstBMP_Info->bmiHeader.biWidth / 2) % 4);
            if (li32Width) li32Width = 4 - li32Width;
            li32Width += (lstBMP_Info->bmiHeader.biWidth / 2);
          break;

          case 8:
            li32Width = (lstBMP_Info->bmiHeader.biWidth % 4);
            if (li32Width) li32Width = 4 - li32Width;
            li32Width += lstBMP_Info->bmiHeader.biWidth;
          break;

          case 24:
            li32Width = ((lstBMP_Info->bmiHeader.biWidth * 3) % 4);
            if (li32Width) li32Width = 4 - li32Width;
            li32Width += lstBMP_Info->bmiHeader.biWidth * 3;
          break;
        }

         lui32BitSize = li32Width * abs(lstBMP_Info->bmiHeader.biHeight);
      }  
    } 
 
    if (!li8Fehler)
    {
      if ((lpui8Bits = (uint8*)malloc(lui32BitSize)) == NULL)
      {
        // Nicht genug Speicher
        free(lstBMP_Info);
        li8Fehler = 1;
      }
    } 

    fseek(lpFile, lstBMP_Header.bfOffBits, SEEK_SET);

    if (!li8Fehler)
    { 
      if (fread(lpui8Bits, 1, lui32BitSize, lpFile) < lui32BitSize)
      {
        //Konnte Bildaten nicht lesen
        free(lstBMP_Info);
        free(lpui8Bits);
        li8Fehler = 1;        
      }
    }


    if (!li8Fehler)
    {
      // Create a bitmap to load the data into
	    if (ScreenInit(lpstDestScreen) != 0)
	    {
        li8Fehler = 1;
	    }

	    if (ScreenCreate(BPP32_8R8G8B,
                       (uint16) lstBMP_Info->bmiHeader.biWidth, 
                       (uint16) abs(lstBMP_Info->bmiHeader.biHeight), 
                       lpstDestScreen) != 0)
	    {
        li8Fehler = 1;
	    }

      if (!li8Fehler)
      {
      
	      int32 li32Cnt1 = 0;
        int32 li32Cnt2 = 0;
        int32 li32i,li32j;
        uint32 liCol;
        int32          li32RGBIndex;

        switch (lstBMP_Info->bmiHeader.biBitCount)
        {
          case 1:
            
            li32Cnt2 = ((lpstDestScreen->ui16Width / 8) % 4);
            if (li32Cnt2) li32Cnt2 = 4 - li32Cnt2;
            li32Cnt2 += (lpstDestScreen->ui16Width/8);
          

            for (li32j = 0; li32j < lpstDestScreen->ui16Height; li32j++) 
            {
		          for (li32i = 0; li32i < lpstDestScreen->ui16Width; li32i++) 
              {
                li32Cnt1 = li32j * li32Cnt2 + li32i / 8;

                switch (li32i % 8)
                {
                  case 7:
                    li32RGBIndex = (lpui8Bits[li32Cnt1] & 0x001);
                  break;
                  case 6:
                    li32RGBIndex = (lpui8Bits[li32Cnt1] & 0x002) >> 1;
                  break;
                  case 5:
                    li32RGBIndex = (lpui8Bits[li32Cnt1] & 0x004) >> 2;
                  break;
                  case 4:
                    li32RGBIndex = (lpui8Bits[li32Cnt1] & 0x008) >> 3;
                  break;
                  case 3:
                    li32RGBIndex = (lpui8Bits[li32Cnt1] & 0x010) >> 4;
                  break;
                  case 2:
                    li32RGBIndex = (lpui8Bits[li32Cnt1] & 0x020) >> 5;
                  break;
                  case 1:
                    li32RGBIndex = (lpui8Bits[li32Cnt1] & 0x040) >> 6;
                  break;
                  case 0:
                    li32RGBIndex = (lpui8Bits[li32Cnt1] & 0x080) >> 7;
                  break;
                }
              
                liCol = BPP32_8R8G8B_RGB( lstBMP_Info->bmiColors[li32RGBIndex].rgbRed, lstBMP_Info->bmiColors[li32RGBIndex].rgbGreen, lstBMP_Info->bmiColors[li32RGBIndex].rgbBlue);

                BPP32_8R8G8B_PXL(li32i, (lpstDestScreen->ui16Height-1) - li32j, lpstDestScreen) = liCol;
              }
            }
          break;

          case 4:

            li32Cnt2 = ((lpstDestScreen->ui16Width / 2) % 4);
            if (li32Cnt2) li32Cnt2 = 4 - li32Cnt2;

            li32Cnt2 += (lpstDestScreen->ui16Width / 2);
          

            for (li32j = 0; li32j < lpstDestScreen->ui16Height; li32j++) 
            {
		          for (li32i = 0; li32i < lpstDestScreen->ui16Width; li32i++) 
              {
                li32Cnt1 = li32j * li32Cnt2 + li32i/2;

                if (li32i & 1)
                {
                  li32RGBIndex = lpui8Bits[li32Cnt1] & 0x0F;                  
                }
                else
                {
                  li32RGBIndex = (lpui8Bits[li32Cnt1] & 0x0F0) >> 4;
                }

              
                liCol = BPP32_8R8G8B_RGB( lstBMP_Info->bmiColors[li32RGBIndex].rgbRed, lstBMP_Info->bmiColors[li32RGBIndex].rgbGreen, lstBMP_Info->bmiColors[li32RGBIndex].rgbBlue);

                BPP32_8R8G8B_PXL(li32i, (lpstDestScreen->ui16Height-1) - li32j, lpstDestScreen) = liCol;
              }
            }
          break;

          case 8:

            li32Cnt2 = (lpstDestScreen->ui16Width % 4);
            if (li32Cnt2) li32Cnt2 = 4 - li32Cnt2;
            li32Cnt2 += lpstDestScreen->ui16Width;
          

            for (li32j = 0; li32j < lpstDestScreen->ui16Height; li32j++) 
            {
		          for (li32i = 0; li32i < lpstDestScreen->ui16Width; li32i++) 
              {
                li32Cnt1 = li32j * li32Cnt2 + li32i;
                li32RGBIndex = lpui8Bits[li32Cnt1];

                liCol = BPP32_8R8G8B_RGB( lstBMP_Info->bmiColors[li32RGBIndex].rgbRed, lstBMP_Info->bmiColors[li32RGBIndex].rgbGreen, lstBMP_Info->bmiColors[li32RGBIndex].rgbBlue);

                BPP32_8R8G8B_PXL(li32i, (lpstDestScreen->ui16Height-1) - li32j, lpstDestScreen) = liCol;
              }
            }
          break;
          case 24:        
            for (li32j = 0; li32j < lpstDestScreen->ui16Height; li32j++) 
            {
		          for (li32i = 0; li32i < lpstDestScreen->ui16Width; li32i++) 
              {                
                BPP32_8R8G8B_PXL(li32i, (lpstDestScreen->ui16Height-1) - li32j, lpstDestScreen) = BPP32_8R8G8B_RGB(lpui8Bits[li32Cnt1 + 2], lpui8Bits[li32Cnt1 + 1], lpui8Bits[li32Cnt1 + 0]);
                li32Cnt1 += 3;
              }
            }
          break;
        }
      }
      free(lstBMP_Info);
      free(lpui8Bits);
    }

    fclose(lpFile);
  }
  return li8Fehler;
}


int8 BPP32_8R8G8B_BMPSave(char *szFilename, Screen *lpstSourceScreen)
{
  FILE             *lpFile;
  uint8            *lpui8Bits;
  uint32           lui32BitSize;
  uint32           lui32InfoSize, lui32Size;
  BITMAPFILEHEADER lstBMP_Header;
  BITMAPINFO       lstBMP_Info;
  int32            li32Width;
  int8             li8Fehler;


  li8Fehler = 0;

  
  SCREEN_CHK_INIT(lpstSourceScreen);
  if (lpstSourceScreen->ui8In_Use == false)
  {
    return 2;
  }  


  // Versuchen Datei zu �ffnen
  if ((lpFile = fopen(szFilename, "wb")) != NULL)
  {

    // Bitmapgr��e ermitteln

    li32Width = ((lpstSourceScreen->ui16Width * 3) % 4);
    if (li32Width) li32Width = 4 - li32Width;

    lstBMP_Info.bmiHeader.biSize           = 40;
    lstBMP_Info.bmiHeader.biSizeImage      = lpstSourceScreen->ui16Width * lpstSourceScreen->ui16Height * 3 + li32Width * lpstSourceScreen->ui16Height;
    lstBMP_Info.bmiHeader.biHeight         = lpstSourceScreen->ui16Height;
    lstBMP_Info.bmiHeader.biWidth          = lpstSourceScreen->ui16Width;
    lstBMP_Info.bmiHeader.biBitCount       = 24;
    lstBMP_Info.bmiHeader.biCompression    = 0;
    lstBMP_Info.bmiHeader.biClrImportant   = 0;
    lstBMP_Info.bmiHeader.biClrUsed        = 0;
    lstBMP_Info.bmiHeader.biPlanes         = 1;
    lstBMP_Info.bmiHeader.biXPelsPerMeter  = 1000;
    lstBMP_Info.bmiHeader.biYPelsPerMeter  = 1000;

    lui32BitSize = lstBMP_Info.bmiHeader.biSizeImage;

    // Headergr��e ermittelt
    lui32InfoSize = sizeof(BITMAPINFOHEADER);

    lui32Size = sizeof(BITMAPFILEHEADER) + lui32InfoSize + lui32BitSize;

    //  File lstBMP_Header, Bitmap Information und Bitmap Pixel Daten schreiben
    lstBMP_Header.bfType      = 'MB'; 
    lstBMP_Header.bfSize      = lui32Size;
    lstBMP_Header.bfReserved1 = 0;
    lstBMP_Header.bfReserved2 = 0;
    lstBMP_Header.bfOffBits   = sizeof(BITMAPFILEHEADER) + lui32InfoSize;

    if (fwrite(&lstBMP_Header, 1, sizeof(BITMAPFILEHEADER), lpFile) < sizeof(BITMAPFILEHEADER))
    {
      li8Fehler = 1;
    }

    if (fwrite(&lstBMP_Info, 1, lui32InfoSize, lpFile) < lui32InfoSize)
    {
      li8Fehler = 1;
    }

    if (!li8Fehler)
    {
      if ((lpui8Bits = (uint8*)malloc(lui32BitSize)) == NULL)
      {
        // Nicht genug Speicher
        li8Fehler = 1;
      }
    }


    if (!li8Fehler)
    {
	    int32 li32Cnt1 = 0;
      int32 li32Cnt2 = 0;
      int32 li32i,li32j;

      li32Cnt2 = ((lpstSourceScreen->ui16Width * 3) % 4);
      if (li32Cnt2) li32Cnt2 = 4 - li32Cnt2;
      li32Cnt2 += lpstSourceScreen->ui16Width * 3;
      

      for (li32j = 0; li32j < lpstSourceScreen->ui16Height; li32j++) 
      {
		    for (li32i = 0; li32i < lpstSourceScreen->ui16Width; li32i++) 
        {
          li32Cnt1 = li32j * li32Cnt2 + li32i * 3;			      
          lpui8Bits[li32Cnt1 + 2] = BPP32_8R8G8B_GET_R(BPP32_8R8G8B_PXL(li32i, lpstSourceScreen->ui16Height - 1 - li32j, lpstSourceScreen));
          lpui8Bits[li32Cnt1 + 1] = BPP32_8R8G8B_GET_G(BPP32_8R8G8B_PXL(li32i, lpstSourceScreen->ui16Height - 1 - li32j, lpstSourceScreen));
          lpui8Bits[li32Cnt1 + 0] = BPP32_8R8G8B_GET_B(BPP32_8R8G8B_PXL(li32i, lpstSourceScreen->ui16Height - 1 - li32j, lpstSourceScreen));
        }
      }
    }

    if (!li8Fehler)
    {
      if (fwrite(lpui8Bits, 1, lui32BitSize, lpFile) < lui32BitSize)
      {
        li8Fehler = 1;
      } 
    }

    free(lpui8Bits);
    fclose(lpFile);
  }

  return li8Fehler;
}

