/****************************************************************************************/
/*! \file PC_typedef.h 
 *  \brief Einige Typedefs f�r PC, ggf. f�r entsprechendes System anpassen
 *  \author Florian Kaes
 *  \version 2005_04_12
 *  \date    12.04.2005
 *  \section history History
 *
 *  \since 12.04.2005
 *  - Erstellt
 */
/****************************************************************************************/


#ifndef _PC_TYPEDEF_H
#define _PC_TYPEDEF_H


#define INLINE _inline

#define nDefCoreType8   0
#define nDefCoreType16  1
#define nDefCoreType32  2
#define nDefCoreType64  3

#define nDefCoreType    nDefCoreType32


#define nDefMemLayoutTiny    0 // <4k
#define nDefMemLayoutSmall   1 // <64k
#define nDefMemLayoutMedium  2 // <512k
#define nDefMemLayoutLarge   3 // >=512k

#define nDefMemLayout   nDefMemLayoutSmall


#define BitPos(Pos) (1<<Pos)

typedef unsigned long int uint64;
typedef unsigned int      uint32;
typedef unsigned short    uint16;
typedef unsigned char     uint8;
//typedef unsigned char     bool;

typedef long int       int64;
typedef int            int32;
typedef short          int16;
typedef char           int8;


typedef uint64   uint64_t;
typedef uint32   uint32_t;
typedef uint16   uint16_t;
typedef uint8    uint8_t;

typedef int64   int64_t;
typedef int32   int32_t;
typedef int16   int16_t;
typedef int8    int8_t;


#if (nDefCoreType == nDefCoreType8)
  typedef uint16 tsize;
#endif
#if (nDefCoreType == nDefCoreType16)
  typedef uint16 tsize;
#endif
#if (nDefCoreType == nDefCoreType32)
  typedef uint32 tsize;
#endif
#if (nDefCoreType == nDefCoreType64)
  typedef uint64 tsize;
#endif

#define UINT32MAX 0xFFFFFFFF
#define UINT16MAX 0xFFFF
#define UINT8MAX  0xFF

#define INT32MAX 2147483647
#define INT16MAX 32767
#define INT8MAX  127

#define INT32MIN ((int32)(-2147483647))
#define INT16MIN ((int16)(-32767))
#define INT8MIN  ((int8)(-127))


// Bitfeld f�r 8 Bit
typedef struct 
{
  uint8 B0:1;
  uint8 B1:1;
  uint8 B2:1;
  uint8 B3:1;
  uint8 B4:1;
  uint8 B5:1;
  uint8 B6:1;
  uint8 B7:1;
}Bit8_struct;

// Union f�r Bitweiser Zugriff auf ein Byte
typedef union 
{
  uint8        ui8Byte;
  Bit8_struct  stBits;
}Bit8_union;


// Union f�r Byteweiser Zugriff auf uint32
typedef union 
{
  uint32       ui32Data;
  uint8        ui8Byte[4];
}tun4Byte;


// Punkt
typedef struct { float  x, y; }  stPxlf;


#define false 0
#define true  (!false)
#define null 0

#define True    (1 == 1 )    /* Boolean value for True       */
#define False   (1 == 0 )    /* Boolean value for False      */


// Keyboard Functions
#include <conio.h>

INLINE int8 KeyBoard_kbhit(void) {return _kbhit();}
INLINE int8 KeyBoard_getch(void) {return _getch();}
INLINE int8 KeyBoard_putch(int8 li8Char) {return _putch(li8Char);}


#define PROGMEM

#endif

