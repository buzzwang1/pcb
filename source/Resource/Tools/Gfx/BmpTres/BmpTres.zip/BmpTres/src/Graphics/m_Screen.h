#ifndef _M_SCREEN
#define _M_SCREEN


#include <malloc.h>
#include "_TypeDef.h"

//Types


#define SCREEN_INITIALIZED 123

#define BPP32_8R8G8B 0

#define RGB_8R8G8B(RED,GREEN,BLUE) ((RED << 8) + GREEN << 8) + BLUE

#define BPP32_8R8G8B_CHECK(lpstScreen)  if (lpstScreen->ui8Type != BPP32_8R8G8B) return 2;
#define BPP32_8R8G8B_MEM(li32Index,      lpstScreen) (uint32)((uint32*)lpstScreen->paui8Screen)[(li32Index)]
#define BPP32_8R8G8B_PXL(lui16X, lui16Y, lpstScreen) BPP32_8R8G8B_MEM(SCREEN_IDX((lui16X), (lui16Y), (lpstScreen)), (lpstScreen))

//Work always but slower 
#define BPP32_8R8G8B_RGB(li32r, li32g, li32b)  ((((li32r) << 8) + (li32g)) << 8) + (li32b)
//#define BPP32_8R8G8B_GET_RGB(lui32Col, li32r, li32g, li32b)  li32r = (lui32Col >> 16) & 255;li32g = (lui32Col >> 8)  & 255;li32b = lui32Col & 255;
//faster, but be careful with little and big endian
#define BPP32_8R8G8B_GET_RGB(lui32Col, li32r, li32g, li32b)  li32r = ((uint8*)(&lui32Col))[2]; li32g = ((uint8*)(&lui32Col))[1]; li32b = ((uint8*)(&lui32Col))[0];
#define BPP32_8R8G8B_GET_R(lui32Col)  ((uint8*)(&lui32Col))[2]
#define BPP32_8R8G8B_GET_G(lui32Col)  ((uint8*)(&lui32Col))[1]
#define BPP32_8R8G8B_GET_B(lui32Col)  ((uint8*)(&lui32Col))[0]



#define BPP8_8G 1


#define BPP8_8G_CHECK(lpstScreen)  if (lpstScreen->ui8Type != BPP8_8G) return 2;
#define BPP8_8G_MEM(li32Index,      lpstScreen) lpstScreen->paui8Screen[(li32Index)]
#define BPP8_8G_PXL(lui16X, lui16Y, lpstScreen) BPP8_8G_MEM(SCREEN_IDX((lui16X), (lui16Y), (lpstScreen)), (lpstScreen))





#define CLIP_COL(li32Col) if (li32Col > 255) li32Col = 255;  if (li32Col < 0) li32Col = 0;
#define SCREEN_PI   3.14159265359f
#define SCREEN_PI2X 2 * SCREEN_PI



#define SCREEN_CHK_INIT(lpstScreen)                       if (lpstScreen->ui8Initialized != SCREEN_INITIALIZED) return 2;
#define SCREEN_CHK_INIT_AND_IN_USE(lpstScreen)            if ((lpstScreen->ui8Initialized != SCREEN_INITIALIZED) || (lpstScreen->ui8In_Use == false)) return 2;
#define SCREEN_CHK_SIZE(lpstSourceScreen, lpstDestScreen) if ((lpstSourceScreen->ui16Width != lpstDestScreen->ui16Width) || (lpstSourceScreen->ui16Height != lpstDestScreen->ui16Height)) return 2;
#define SCREEN_CHK_POS(lui16x, lui16y, lpstScreen)        if ((lui16x < 0) || (lui16y < 0) || ((lui16x > lpstScreen->ui16Width - 1)) || (lui16y > lpstScreen->ui16Height - 1)) return 2;
#define SCREEN_POSX(lui32Index, lpstScreen)               ((lui32Index) % lpstSourceScreen->ui16Width)
#define SCREEN_POSY(lui32Index, lpstScreen)               ((lui32Index) / lpstSourceScreen->ui16Width)
#define SCREEN_IDX(lui16x, lui16y, lpstScreen)            ((uint32)((lui16y) * lpstScreen->ui16Width + (lui16x)))
#define SCREEN_SIZE(lpstScreen)                           (lpstScreen->ui16Width * lpstScreen->ui16Height)
#define SCREEN_CLONE(lpstSourceScreen, lpstDestScreen)    ScreenCreate(lpstSourceScreen->ui8Type, lpstSourceScreen->ui16Width, lpstSourceScreen->ui16Height, lpstDestScreen)

typedef struct ScreenStruct Screen;

struct ScreenStruct
{
  uint32 ui32ID;

  uint16  ui16Height;       // Height 
  uint16  ui16Width;        // Width  
  uint8  *paui8Screen;      // Pixel memory
  uint8   ui8Type;          // Type of screen e.g. Color or grey
  uint8   ui8BPP;           // Byte ber Pixel
  uint8   ui8In_Use;        // show, if the screen was created
  uint8   ui8Initialized;   // show, if the screen was initialized
  Screen *pstParentScreen;  // only for AOIs (Area of interest)
  
  void   *vpNext;
};
  

extern int8 ScreenInit(Screen *lpstScreen);
extern int8 ScreenCreate(uint8 ui8Type, uint16 ui16Width, uint16 ui16Height, Screen *lpstScreen);
extern int8 ScreenCreateAOI(uint16 lui16x, uint16 lui16y, uint16 ui16Width, uint16 ui16Height, Screen *lpstSourceScreen, Screen *lpstAOI);
extern int8 ScreenDelete(Screen *lpstScreen);
  

//inline int Abs(int i) {return i<0?-i:i;};

#endif

