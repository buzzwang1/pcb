#ifndef _M_BPP32_8R8G8B_PICTURE
#define _M_BPP32_8R8G8B_PICTURE

#include <stdlib.h>      
#include <stdio.h>
#include <memory.h>
#include <malloc.h>
#include "windows.h"

#include "_TypeDef.h"
#include "m_Screen.h"
#include "m_BPP32_8R8G8B_Tools.h"

typedef union  // Deklaration eines neuen Datentyps 
{ 
  uint32 ui32RGB32; 

  struct
  {
	  uint8 ui8R;
	  uint8 ui8G;
	  uint8 ui8B;
	  uint8 ui8Dummy;
  }stRGB32;
}unRGB32;


typedef struct
{
   uint8  ui8IIFsize;            // IIF size (after header), usually 0
   uint8  ui8Cmap_Type;           // ignored
   uint8  ui8Image_Type;          // should be 2
   uint8  ui8Pad[5];

   uint16 ui8X;
   uint16 ui8Y;
   uint16 ui8Width;
   uint16 ui8Height;

   uint8  ui8PixelSize;        // 16, 24, or 32
   uint8  ui8ImageDesciptor;   // Bits 3-0: size of alpha channel
                               // Bit 4:    must be 0 (reserved)
                               // Bit 5:    should be 0 (origin)
                               // Bits 6-7: should be 0 (interleaving)
}TGAHeader;


extern int8 BPP32_8R8G8B_TGALoad(char *szFilename, Screen *lpstDestScreen);
extern int8 BPP32_8R8G8B_BMPLoad(char *szFilename, Screen *lpstDestScreen);
extern int8 BPP32_8R8G8B_BMPSave(char *szFilename, Screen *lpstSourceScreen);


#endif



