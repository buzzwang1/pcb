/****************************************************************************************/
/*! \file m_Screen.c
 *  \brief Basic Screen funktionen. Kann auch als "Area of Interest" benutzt werden
 *  \author Florian Kaes
 *  \version <2007_04_08>
 *  \date    08.04.2007
 *  \section history History
 *
 *  \since 08.04.2007
 *  - Erstellt
 */
/****************************************************************************************/



//#include <memory.h>
#include "m_Screen.h"


/****************************************************************************************/
/*! \fn int8 ScreenInit(Screen *lpstScreen)
 *  \brief Initialisier den �bergebene Screen 
 *  \param *lpstScreen Screen: R�ckgabewert: Screen, der ausgef�llt wird
 *  \return int8
 *  -  0: kein Fehler
 *  -  1: allg. Fehler
 *  -  2: �bergabefehler
 *  -  sonst: allg. Fehler
 *  \author Florian Kaes
 *  \section history History
 *  \since 08.04.2007
 *  - Erstellt
 */
/****************************************************************************************/
int8 ScreenInit(Screen *lpstScreen)
{

  if ((lpstScreen->ui8Initialized == SCREEN_INITIALIZED) &&
      (lpstScreen->ui8In_Use != false))
  {
    ScreenDelete(lpstScreen);
  }

  lpstScreen->ui8In_Use      = false;
  lpstScreen->paui8Screen    = null;
  lpstScreen->pstParentScreen= null;

  lpstScreen->ui8Type        = BPP32_8R8G8B;
  lpstScreen->ui8BPP         = 4;
  
  lpstScreen->ui8Initialized = SCREEN_INITIALIZED;
  lpstScreen->vpNext         = null;
  lpstScreen->ui32ID         = 2;

  return 0;
}


/****************************************************************************************/
/*! \fn int8 ScreenCreate(uint8 ui8Type, uint16 ui16Width, uint16 ui16Height, Screen *lpstScreen)
 *  \brief Erzeugt den �bergebene Screen, falls er schon besteht wird er weiterverwendet
 *  \param ui8Type uint8: Farbinformation, siehe Defines in der .h Datei 
 *  \param ui16Width uint16: Breite in Pixel
 *  \param ui16Height uint16: H�he in Pixel
 *  \param *lpstScreen Screen: R�ckgabewert: Screen, der ausgef�llt wird
 *  \return int8
 *  -  0: kein Fehler
 *  -  1: allg. Fehler
 *  -  2: �bergabefehler
 *  -  sonst: allg. Fehler
 *  \author Florian Kaes
 *  \section history History
 *  \since 08.04.2007
 *  - Erstellt
 */
/****************************************************************************************/
int8 ScreenCreate(uint8 ui8Type, uint16 ui16Width, uint16 ui16Height, Screen *lpstScreen)
{
  SCREEN_CHK_INIT(lpstScreen);


  if (lpstScreen->ui8In_Use != false) 
  {
	  if ((lpstScreen->ui8Type    == ui8Type) && 
        (lpstScreen->ui16Width  == ui16Width) && 
        (lpstScreen->ui16Height == ui16Height))
	  {
	  }
	  else
	  {
	    ScreenDelete(lpstScreen);
	    lpstScreen->paui8Screen  = null;

      lpstScreen->ui8Type        = ui8Type;

      switch (ui8Type)
      {       
        case BPP8_8G:
          lpstScreen->ui8BPP = 1;
        break;

        case BPP32_8R8G8B:
          lpstScreen->ui8BPP = 4;
        break;

        default:
          lpstScreen->ui8BPP = 4;
      }

      lpstScreen->ui16Width    = ui16Width;
      lpstScreen->ui16Height   = ui16Height;
      lpstScreen->paui8Screen  = (uint8*)malloc(ui16Width * ui16Height *lpstScreen->ui8BPP);
      //memset(lpstScreen->paui8Screen, 0, lui16x*lui16y*lpstScreen->ui8BPP);
	  }
  }
  else
  {
    lpstScreen->ui8Type        = ui8Type;

    switch (ui8Type)
    {       
      case BPP8_8G:
        lpstScreen->ui8BPP = 1;
      break;

      case BPP32_8R8G8B:
        lpstScreen->ui8BPP = 4;
      break;

      default:
        lpstScreen->ui8BPP = 4;
    }

    lpstScreen->ui16Width    = ui16Width;
    lpstScreen->ui16Height   = ui16Height;
    lpstScreen->paui8Screen  = (uint8*)malloc(ui16Width * ui16Height *lpstScreen->ui8BPP);
    //memset(lpstScreen->paui8Screen, 0, lui16x*lui16y*lpstScreen->ui8BPP);
  }

  if (lpstScreen->paui8Screen != null) lpstScreen->ui8In_Use = true;
                                  else lpstScreen->ui8In_Use = false;  

  return 0;
}



/****************************************************************************************/
/*! \fn int8 ScreenCreateAOI(uint16 lui16x, uint16 lui16y, uint16 ui16Width, uint16 ui16Height, Screen *lpstSourceScreen, Screen *lpstAOI)
 *  \brief Erzeugt einen AOI (Area Of Interest) auf einem bestehenden Screen
 *  \param lui16x uint16: Position im SourceScreen
 *  \param lui16y uint16: Position im SourceScreen
 *  \param ui16Width uint16: Breite in Pixel
 *  \param ui16Height uint16: H�he in Pixel
 *  \param *lpstScreen Screen: R�ckgabewert: Screen, der ausgef�llt wird
 *  \return int8
 *  -  0: kein Fehler
 *  -  1: allg. Fehler
 *  -  2: �bergabefehler
 *  -  sonst: allg. Fehler
 *  \author Florian Kaes
 *  \section history History
 *  \since 14.04.2007
 *  - Erstellt
 */
/****************************************************************************************/
int8 ScreenCreateAOI(uint16 lui16x, uint16 lui16y, uint16 ui16Width, uint16 ui16Height, Screen *lpstSourceScreen, Screen *lpstAOI)
{
  SCREEN_CHK_INIT(lpstSourceScreen);
  SCREEN_CHK_INIT(lpstAOI);
  SCREEN_CHK_POS(lui16x, lui16y, lpstSourceScreen);

  if (lpstSourceScreen->ui8In_Use == false)  return 2;


  //Clip AOI if necessaray
  if ((lui16x + ui16Width)  > lpstSourceScreen->ui16Width) ui16Width  = lpstSourceScreen->ui16Width  - lui16x;
  if ((lui16y + ui16Height) > lpstSourceScreen->ui16Width) ui16Height = lpstSourceScreen->ui16Height - lui16y;
    
  
  lpstAOI->pstParentScreen = lpstSourceScreen; 
  ScreenDelete(lpstAOI);

  lpstAOI->paui8Screen  = &lpstSourceScreen->paui8Screen[SCREEN_IDX(lui16x, lui16y, lpstSourceScreen)] ;

  lpstAOI->ui16Width    = ui16Width;
  lpstAOI->ui16Height   = ui16Height;
  lpstAOI->ui8In_Use    = false;

  return 0;
}




/****************************************************************************************/
/*! \fn int8 ScreenDelete(Screen *lpstScreen)
 *  \brief L�scht den �bergebene Screen, gibt den Speicher frei
 *  \param *lpstScreen Screen: R�ckgabewert: Screen, der gel�scht wird
 *  \return int8
 *  -  0: kein Fehler
 *  -  1: allg. Fehler
 *  -  2: �bergabefehler
 *  -  sonst: allg. Fehler
 *  \author Florian Kaes
 *  \section history History
 *  \since 08.04.2007
 *  - Erstellt
 */
/****************************************************************************************/
int8 ScreenDelete(Screen *lpstScreen)
{
  lpstScreen->ui16Width  = 0;
  lpstScreen->ui16Height = 0;

  if (lpstScreen->ui8In_Use) 
  {
    //Don't kill AIO mem !
    if (lpstScreen->pstParentScreen == null)
    {
	    free(lpstScreen->paui8Screen);
    }

	  lpstScreen->paui8Screen = null;
  }

  lpstScreen->ui8In_Use = false;

  return 0;
}






