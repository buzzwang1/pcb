#ifndef _M_BPP32_8R8G8B_TOOLS
#define _M_BPP32_8R8G8B_TOOLS


#include <memory.h>
#include "m_Screen.h"
#include "_TypeDef.h"

typedef union  // Deklaration eines neuen Datentyps 
{ 
 int RGB32; 

 struct
 {	 
	 uint8 ui8b;
   uint8 ui8g;
	 uint8 ui8r;
	 uint8 ui8dummy;
 }RGB24;
}unBPP32_8R8G8B_RGB;



extern int8 BPP32_8R8G8B_SetPixel(int32 li32X,int32 li32Y, uint32 lui32Col, Screen *lstScreen);
extern int8 BPP32_8R8G8B_GetPixel(int32 li32X,int32 li32Y,Screen *lstScreen, uint32 *lui32Col);
extern int8 BPP32_8R8G8B_ClearScreen(uint32 lui32Col, Screen* lpstScreen);
extern int8 BPP32_8R8G8B_Fade_to_Black(int32 li32Speed, Screen* lpstScreen, int32 *li32Ready);
extern int8 BPP32_8R8G8B_Fade_to(int32 li32Speed, Screen* lpstSourceScreen,Screen* lpstFadeScreen, int32 *li32Ready);
extern int8 BPP32_8R8G8B_CopyScreenRaw(Screen* lstScreenFrom,Screen* lstScreenTo);
extern int8 BPP32_8R8G8B_SubScreen(Screen* lstSourceScreen1, int Percent1, int TransCol1,
                                   Screen* lstSourceScreen2, int Percent2, int TransCol2,
                                   Screen* lstScreenTo);
extern int8 BPP32_8R8G8B_BPP32_8R8G8B_AddValue(int32 li32Value, Screen* lpstSourceScreen, Screen* lpstDestScreen);
extern int8 BPP32_8R8G8B_AddScreen(Screen* lstSourceScreen1, int Percent1, int TransCol1,
                                   Screen* lstSourceScreen2, int Percent2, int TransCol2,
                                   Screen* lstScreenTo);
extern int8 BPP32_8R8G8B_InterpolX(Screen* lpstSourceScreen, Screen* lpstDestScreen);
extern int8 BPP32_8R8G8B_InterpolY(Screen* lpstSourceScreen, Screen* lpstDestScreen);
extern int8 BPP32_8R8G8B_InterpolX_Seem(Screen* lpstSourceScreen, Screen* lpstDestScreen);
extern int8 BPP32_8R8G8B_InterpolXY_Seem(Screen* lstSourceScreen,Screen* lstDestScreen);
extern int8 BPP32_8R8G8B_InterpolY_Seem(Screen* lpstSourceScreen, Screen* lpstDestScreen);
extern int8 BPP32_8R8G8B_ScrolllScreen(uint32 lui32Xadd, uint32 lui32Yadd, Screen* lstSourceScreen,Screen* lstDestScreen);
extern int8 BPP32_8R8G8B_ANDValue(uint32 lui32Value, Screen *lpstSourceScreen, Screen *lpstDestScreen);
extern int8 BPP32_8R8G8B_ORValue( uint32 lui32Value, Screen *lpstSourceScreen, Screen *lpstDestScreen);
extern int8 BPP32_8R8G8B_XORValue(uint32 lui32Value, Screen *lpstSourceScreen, Screen *lpstDestScreen);
extern int8 BPP32_8R8G8B_NOTScreen(Screen* lpstSourceScreen, Screen* lpstDestScreen);
extern int8 BPP32_8R8G8B_RGB_NEGScreen(Screen* lpstSourceScreen, Screen* lpstDestScreen);
extern int8 BPP32_8R8G8B_ANDScreen(Screen* lpstSourceScreen1, 
                                   Screen* lpstSourceScreen2,
                                   Screen* lpstDestScreen);
extern int8 BPP32_8R8G8B_ORScreen(Screen* lpstSourceScreen1, 
                                  Screen* lpstSourceScreen2,
                                  Screen* lpstDestScreen);
extern int8 BPP32_8R8G8B_XORScreen(Screen* lpstSourceScreen1, 
                                   Screen* lpstSourceScreen2,
                                   Screen* lpstDestScreen);

extern int8 BPP32_8R8G8B_MAXScreen(Screen* lpstSourceScreen1, 
                                   Screen* lpstSourceScreen2,
                                   Screen* lpstDestScreen);
extern int8 BPP32_8R8G8B_MAXScreen(Screen* lpstSourceScreen1, 
                                   Screen* lpstSourceScreen2,
                                   Screen* lpstDestScreen);


extern int8 BPP32_8R8G8B_ScallScreen(Screen* lpstSourceScreen,Screen* lpstDestScreen);
extern int8 BPP32_8R8G8B_ScreenFlipX(Screen* lpstSourceScreen, Screen* lpstDestScreen);
extern int8 BPP32_8R8G8B_ScreenFlipY(Screen* lpstSourceScreen, Screen* lpstDestScreen);
extern int8 BPP32_8R8G8B_ScreenGrey(Screen* lpstSourceScreen, Screen* lpstDestScreen);

#endif
