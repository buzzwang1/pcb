/****************************************************************************************/
/*! \file TypeDef.h 
 *  \brief Einige Typedefs f�r PC, ggf. f�r entsprechendes System anpassen
 *  \author Florian Kaes
 *  \version 2007_04_08
 *  \date    08.04.2007
 *  \section history History
 *
 *  \since 08.04.2007
 *  - Erstellt
 */
/****************************************************************************************/



#ifndef _TYPEDEF_H
#define _TYPEDEF_H

#include "_PC_TypeDef.h"


#endif

