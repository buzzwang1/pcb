// SuperSizeMe.cpp : Definiert den Einsprungpunkt f�r die Konsolenanwendung.
//

#include <stdlib.h>
#include <stdio.h>

#define SUPER_SIZE_LINE_COL   BPP32_8R8G8B_RGB(0, 0, 0)

#include "_m_BPP32_8R8G8B_Tools.h"
#include "_m_BPP32_8R8G8B_Pattern.h"
#include "_m_BPP32_8R8G8B_Picture.h"
#include "_m_Screen.h"
#include "_TypeDef.h"

Screen mstTestScreen01;

int main(int argc, char* argv[])
{
  uint32 lui32Threshold;


  uint32 lui32t;

  char   lszDestFile[256];
  char   lszSourceFile[256];
  char   lszExtension[256];

  for(lui32t=0; lui32t < (uint32)argc; lui32t++)
  {
     printf("argv[%d] = %s ",lui32t,argv[lui32t]);
     printf("\n");
  }

  if (argc < 3) 
  {
    printf("At least one Parameter is missing !\n");
    printf("e.g. [SourceBitmap] [Threshold] [DestBitmap]\n");
    printf("e.g. [SourceBitmap]  = Testin.Bmp\n");
    printf("e.g. [Threshold]     = 255 oder 0xFFFFFF\n");
    printf("e.g. [DestBitmap]    = Testout.Bmp\n");

    return 0;
  }

  strlwr(argv[2]);
  if ((argv[2][0] == 'x') || (argv[2][1] == 'x'))
  {
    lui32Threshold     = (uint32)strtol(argv[2], NULL, 16);
  }
  else
  {
    lui32Threshold     = atoi(argv[2]);
  }


  strcpy(lszSourceFile, argv[1]);

  if (strlen(lszSourceFile) < 5) 
  {
    printf("Dest Image is missing !\n");
    return 0;
  }

  strcpy(lszDestFile, argv[3]);

  if (strlen(lszDestFile) < 5) 
  {
    printf("Dest Image is missing !\n");
    return 0;
  }

  /*strncpy(lszExtension, lszDestFile + strlen(lszDestFile) - 3, 4);

  if (strcmp(lszExtension, "bmp") != 0) 
  {
    printf("Dest Image is wrong. Only BMP !\n");
    return 0;
  }*/

  ScreenInit(&mstTestScreen01);
        
  if (BPP32_8R8G8B_BMPLoad(lszSourceFile, &mstTestScreen01) == 0)
  {    
    uint32 lui32colRThres;
    uint32 lui32colGThres;
    uint32 lui32colBThres;

    uint32 lui32col;
    uint32 lui32colR;
    uint32 lui32colG;
    uint32 lui32colB;

    BPP32_8R8G8B_GET_RGB(lui32Threshold, lui32colRThres, lui32colGThres, lui32colBThres);


    for (lui32t = 0; lui32t < (mstTestScreen01.ui16Height * mstTestScreen01.ui16Width); lui32t++)
    {
      lui32col = BPP32_8R8G8B_MEM(lui32t, (&mstTestScreen01));
      BPP32_8R8G8B_GET_RGB(lui32col, lui32colR, lui32colG, lui32colB);

      if ((lui32colR >= lui32colRThres) &&
          (lui32colG >= lui32colGThres) &&
          (lui32colB >= lui32colBThres))
      {
        BPP32_8R8G8B_MEM(lui32t, (&mstTestScreen01)) = 0xFFFFFF;
      }
      else
      {
        BPP32_8R8G8B_MEM(lui32t, (&mstTestScreen01)) = 0x0;
      }
    }

    BPP32_8R8G8B_BMPSave(lszDestFile, &mstTestScreen01);

    printf(lszDestFile);
    printf(" was generated \n");
  }
  else
  {
    printf("Was not able to convert !\n");
  }


	return 0;
}

