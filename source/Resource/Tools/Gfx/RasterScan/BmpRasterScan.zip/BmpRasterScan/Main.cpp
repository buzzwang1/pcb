// SuperSizeMe.cpp : Definiert den Einsprungpunkt f�r die Konsolenanwendung.
//

#include <stdlib.h>
#include <stdio.h>

#define SUPER_SIZE_LINE_COL   BPP32_8R8G8B_RGB(0, 0, 0)

#include "_m_BPP32_8R8G8B_Tools.h"
#include "_m_BPP32_8R8G8B_Pattern.h"
#include "_m_BPP32_8R8G8B_Picture.h"
#include "_m_Screen.h"
#include "_TypeDef.h"

Screen mstTestScreen01;


typedef struct
{
  int32 i32X1;
  int32 i32Y1;
  int32 i32X2;
  int32 i32Y2;
} tstRect;



void vScanBlock(tstRect* lstRect, Screen* lpstScreen)
{
  uint32 lui32Col;
  int32  li32t;
  int32  li32Found;

  //Scannen von oben nach unten
  li32Found = 0;
  while ((!li32Found) && (lstRect->i32Y1) <= (lstRect->i32Y2))
  {
    for (li32t = lstRect->i32X1; li32t <= lstRect->i32X2; li32t++)
    {
      lui32Col = BPP32_8R8G8B_PXL(li32t, lstRect->i32Y1, lpstScreen);
      if (((lui32Col & 0xFFFFFF) == 0xFFFFFF) || ((lui32Col & 0xFFFFFF) == 0x7F7F7F))
      {
        li32Found = 1;
      }
    }
    if (!li32Found) lstRect->i32Y1++;
  }


  //Scannen unten nach oben
  li32Found = 0;
  while ((!li32Found) && (lstRect->i32Y2) >= (lstRect->i32Y1))
  {
    for (li32t = lstRect->i32X1; li32t <= lstRect->i32X2; li32t++)
    {
      lui32Col = BPP32_8R8G8B_PXL(li32t, lstRect->i32Y2, lpstScreen);
      if (((lui32Col & 0xFFFFFF) == 0xFFFFFF) || ((lui32Col & 0xFFFFFF) == 0x7F7F7F))
      {
        li32Found = 1;
      }
    }
    if (!li32Found) lstRect->i32Y2--;
  }


  //Scannen links nach rechts
  li32Found = 0;
  while ((!li32Found) && (lstRect->i32X1) <= (lstRect->i32X2))
  {
    for (li32t = lstRect->i32Y1; li32t <= lstRect->i32Y2; li32t++)
    {
      lui32Col = BPP32_8R8G8B_PXL(lstRect->i32X1, li32t, lpstScreen);
      if (((lui32Col & 0xFFFFFF) == 0xFFFFFF) || ((lui32Col & 0xFFFFFF) == 0x7F7F7F))
      {
        li32Found = 1;
      }
    }
    if (!li32Found) lstRect->i32X1++;
  }

  //Scannen von rechts nach links
  li32Found = 0;
  while ((!li32Found) && (lstRect->i32X2) >= (lstRect->i32X1))
  {
    for (li32t = lstRect->i32Y1; li32t <= lstRect->i32Y2; li32t++)
    {
      lui32Col = BPP32_8R8G8B_PXL(lstRect->i32X2, li32t, lpstScreen);
      if (((lui32Col & 0xFFFFFF) == 0xFFFFFF) || ((lui32Col & 0xFFFFFF) == 0x7F7F7F))
      {
        li32Found = 1;
      }
    }
    if (!li32Found) lstRect->i32X2--;
  }
}


int main(int argc, char* argv[])
{
  uint32 lui32NewWidth;
  uint32 lui32NewHeight;

  uint32 lui32BlockCntX;
  uint32 lui32BlockCntY;
  uint32 lui32BlockSizeX;
  uint32 lui32BlockSizeY;
  uint32 lui32OffsetY;

  uint32 lui32t;
  uint32 lui32tX;
  uint32 lui32tY;

  FILE*  lstDstFile;
  char   lszSrcFile[256];
  char   lszDstFile[256];
  char   lszExtension[256];
  char   lszCharacter[8];

  tstRect lstRect;

  lszCharacter[1] = 0;

  for(lui32t=0; lui32t < (uint32)argc; lui32t++)
  {
     printf("argv[%d] = %s ",lui32t,argv[lui32t]);
     printf("\n");
  }

  if (argc < 6) 
  {
    printf("At least one Parameter is missing !\n");
    printf("e.g. [BlockCntX] [BlockCntY] [BlockSizeX] [BlockSizeY] [OffsetY] [SourceBitmap]\n");
    printf("e.g. [BlockCntX]     = 16\n");
    printf("e.g. [BlockCntY]     = 16\n");
    printf("e.g. [BlockSizeX]    = 16\n");
    printf("e.g. [BlockSizeY]    = 16\n");
    printf("e.g. [OffsetY]       = 2\n");
    printf("e.g. [SourceBitmap]  = Test.Bmp\n");

    return 0;
  }

  lui32BlockCntX     = atoi(argv[1]);
  lui32BlockCntY     = atoi(argv[2]);
  lui32BlockSizeX    = atoi(argv[3]) + 1;
  lui32BlockSizeY    = atoi(argv[4]) + 1;
  lui32OffsetY       = atoi(argv[5]);

  if ((lui32BlockCntX < 1) || (lui32BlockCntX > 1023))
  {
    printf("[BlockCntX] Parameter is not ok !\n");
    return 0;
  }

  if ((lui32BlockCntY < 1) || (lui32BlockCntY > 1023))
  {
    printf("[BlockCntY] Parameter is not ok !\n");
    return 0;
  }

  if ((lui32BlockSizeX < 1) || (lui32BlockSizeX > 1023))
  {
    printf("[BlockSizeX] Parameter is not ok !\n");
    return 0;
  }

  if ((lui32BlockSizeY < 1) || (lui32BlockSizeY > 1023))
  {
    printf("[BlockSizeY] Parameter is not ok !\n");
    return 0;
  }


  strcpy(lszSrcFile, argv[6]);

  if (strlen(lszSrcFile) < 5) 
  {
    printf("Source Image is missing !\n");
    return 0;
  }

  strncpy(lszDstFile, lszSrcFile, strlen(lszSrcFile) - 3);
  lszDstFile[strlen(lszSrcFile) - 3] = 0;
  strcat(lszDstFile, "csv");

  ScreenInit(&mstTestScreen01);
  BPP32_8R8G8B_BMPLoad(lszSrcFile, &mstTestScreen01);
        
  lui32NewWidth  =  lui32BlockCntX * lui32BlockSizeX;
  if (mstTestScreen01.ui16Width < lui32NewWidth)  
  {
    printf("Source Image is to small (x) !\n");
    return 0;
  } 

  lui32NewHeight =  lui32BlockCntY * lui32BlockSizeY;
  if (mstTestScreen01.ui16Height < lui32NewHeight)  
  {
    printf("Source Image is to small (y) !\n");
    return 0;
  }

  lstDstFile = fopen(lszDstFile, "w");
  if (lstDstFile != NULL)
  {
    uint32 lui32Cnt;
    uint32 lui32Header;
    uint32 lui32MaxHeight;
    uint32 lui32MaxYPos;
    uint32 lui32MaxYNeg;
    uint32 lui32Temp;

    // Einmal durchlaufen lassen um H�he
    lui32Cnt       = 0;
    lui32Header    = 0;
    lui32MaxHeight = 0;
    lui32MaxYPos   = 0;
    lui32MaxYNeg   = 0;

    for (lui32tY = 0; lui32tY < lui32BlockCntY; lui32tY++)
    {
      uint32 lui32PosY;
      lui32PosY = lui32tY * lui32BlockSizeY;

      for (lui32tX = 0; lui32tX < lui32BlockCntX; lui32tX++)
      {
        uint32 lui32PosX;

        lui32PosX = lui32tX * lui32BlockSizeX;

        lstRect.i32X1 = lui32PosX + 1;
        lstRect.i32Y1 = lui32PosY + 1;
        lstRect.i32X2 = lui32PosX + lui32BlockSizeX - 1;
        lstRect.i32Y2 = lui32PosY + lui32BlockSizeY - 1;

        vScanBlock(&lstRect, &mstTestScreen01);

        if ((lstRect.i32X1 <= lstRect.i32X2) &&
            (lstRect.i32Y1 <= lstRect.i32Y2))
        {
          if (((lui32PosY + lui32BlockSizeY - 1) - lui32OffsetY) > lstRect.i32Y1)
          {
            lui32Temp = ((lui32PosY + lui32BlockSizeY - 1) - lui32OffsetY) - lstRect.i32Y1;
            if (lui32Temp > lui32MaxYPos)
            {
              lui32MaxYPos = lui32Temp;
            }
          }

          if (lstRect.i32Y2 > ((lui32PosY + lui32BlockSizeY - 1) - lui32OffsetY))
          {
            lui32Temp = lstRect.i32Y2 - ((lui32PosY + lui32BlockSizeY - 1) - lui32OffsetY);
            if (lui32Temp > lui32MaxYNeg)
            {
              lui32MaxYNeg = lui32Temp;
            }
          }
        }
      }
    }

    lui32MaxHeight = lui32MaxYPos + lui32MaxYNeg;

    lui32Cnt    = 0;
    lui32Header = 1;
    for (lui32tY = 0; lui32tY < lui32BlockCntY; lui32tY++)
    {
      uint32 lui32PosY;
      lui32PosY = lui32tY * lui32BlockSizeY;

      for (lui32tX = 0; lui32tX < lui32BlockCntX; lui32tX++)
      {
        uint32 lui32PosX;

        lui32PosX = lui32tX * lui32BlockSizeX;

        lstRect.i32X1 = lui32PosX + 1;
        lstRect.i32Y1 = lui32PosY + 1;
        lstRect.i32X2 = lui32PosX + lui32BlockSizeX - 1;
        lstRect.i32Y2 = lui32PosY + lui32BlockSizeY - 1;

        vScanBlock(&lstRect, &mstTestScreen01);

        if ((lstRect.i32X1 <= lstRect.i32X2) &&
            (lstRect.i32Y1 <= lstRect.i32Y2))
        {
          lszCharacter[0] = lui32Cnt;
          fprintf(lstDstFile, "%d\t%s\t%d\t%d\t%d\t%d\t%d\t%d\t%s\t%s\t''%s'",
                     lui32Cnt,
                     "SpriteWH",
                     lstRect.i32X1 - lui32PosX - 1, // OffsetX
                     lui32PosY + lui32BlockSizeY - 1 - lstRect.i32Y2 - lui32OffsetY, // OffsetY
                     lstRect.i32X1, // x
                     lstRect.i32Y1, // y
                     lstRect.i32X2 - lstRect.i32X1 + 1, // Width
                     lstRect.i32Y2 - lstRect.i32Y1 + 1, // Height
                     "1BPP",
                     "RAW",
                     lszCharacter);
          
          if (lui32Header)
          {
            lui32Header = 0;
            fprintf(lstDstFile, "\t%d\t%d\t%d",
                     1, // Spacing
                     lui32MaxHeight, // MaxHeight
                     lui32OffsetY);  // Offset
          }

          fprintf(lstDstFile, "\n");
        }

        lui32Cnt++;
      }
    }

    printf(lszSrcFile);
    printf(" Raster scanned \n");
    fclose(lstDstFile);
  }



	return 0;
}

