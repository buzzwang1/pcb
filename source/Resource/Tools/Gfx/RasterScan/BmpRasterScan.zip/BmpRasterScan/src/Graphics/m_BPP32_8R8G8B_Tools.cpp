#include "m_BPP32_8R8G8B_Tools.h"


int8 BPP32_8R8G8B_SetPixel(int32 li32X, int32 li32Y, uint32 lui32Col, Screen *lpstScreen)
{
  SCREEN_CHK_INIT(lpstScreen);
  SCREEN_CHK_POS(li32X, li32Y, lpstScreen);
  BPP32_8R8G8B_CHECK(lpstScreen);

  BPP32_8R8G8B_PXL(li32X,li32Y, lpstScreen) = lui32Col;
  return 0;
}

int8 BPP32_8R8G8B_GetPixel(int32 li32X, int32 li32Y, Screen *lpstScreen, uint32 *lui32Col)
{
   *lui32Col = 0;
  SCREEN_CHK_INIT(lpstScreen);
  SCREEN_CHK_POS(li32X, li32Y, lpstScreen);
  BPP32_8R8G8B_CHECK(lpstScreen);

  *lui32Col = BPP32_8R8G8B_PXL(li32X, li32Y, lpstScreen);

  return 0;
}

int8 BPP32_8R8G8B_ClearScreen(uint32 lui32Col, Screen* lpstScreen)
{   
  int32 *lpi32Dest =  (int32*)lpstScreen->paui8Screen;
  int32 li32count  =  SCREEN_SIZE(lpstScreen) - 1;
  int32 li32i;

  SCREEN_CHK_INIT(lpstScreen);
  BPP32_8R8G8B_CHECK(lpstScreen);

  #ifdef VC_ASM_CODE
   __asm
  {
     cld
     mov ecx, li32count
     mov edi, lpi32Dest
     mov eax, lui32Col
     rep stosd
  }
  #else
     #ifdef DEV_ASM_CODE
       __asm
	    (
         "cld\n"
         "mov %ecx, li32count\n"
         "mov %edi, lpi32Dest\n"
         "mov %eax, lui32Col\n"
         "rep stosd\n"    	   
       );
     #else

       for (li32i=0; li32i <= li32count; li32i++) lpi32Dest[li32i] = lui32Col;

     #endif
  #endif

  return 0;
}


int8 BPP32_8R8G8B_Fade_to_Black(int32 li32Speed, Screen* lpstScreen, int32 *li32Ready)
{
  int32  li32r,li32b,li32g;
  uint32 lui32Col;
  uint32 lui32x;
  uint32 lui32y;

 *li32Ready = 1;

  SCREEN_CHK_INIT(lpstScreen);
  BPP32_8R8G8B_CHECK(lpstScreen);

  if (li32Speed > 255) li32Speed = 255;

  for (lui32x = 0; lui32x < (lpstScreen->ui16Width); lui32x++)
  {
     for (lui32y = 0; lui32y < lpstScreen->ui16Height; lui32y++)
     {
        lui32Col = BPP32_8R8G8B_PXL(lui32x, lui32y, lpstScreen);

        if (lui32Col != 0)
        {
           *li32Ready = 0;

           BPP32_8R8G8B_GET_RGB(lui32Col, li32r, li32g, li32b)

           if (li32r > li32Speed) li32r-= li32Speed;
                             else li32r = 0;
           if (li32g > li32Speed) li32g-= li32Speed;
                             else li32g = 0;
           if (li32b > li32Speed) li32b-= li32Speed;
                             else li32b = 0;
          
           BPP32_8R8G8B_PXL(lui32x, lui32y, lpstScreen) = BPP32_8R8G8B_RGB(li32r, li32g, li32b);
        }
     }
  }

  return 0;
}

int8 BPP32_8R8G8B_Fade_to(int32 li32Speed, Screen* lpstSourceScreen,Screen* lpstFadeScreen, int32 *li32Ready)
{
  int32 li32Fr,li32Fb,li32Fg;
  int32 li32Fcol;
  int32 li32Sr,li32Sb,li32Sg;
  int32 li32Scol;

  uint32 li32x1,li32x2;
  uint32 li32y1,li32y2;

  *li32Ready = 1;

  SCREEN_CHK_INIT(lpstSourceScreen);
  BPP32_8R8G8B_CHECK(lpstSourceScreen);
  SCREEN_CHK_INIT(lpstFadeScreen);
  BPP32_8R8G8B_CHECK(lpstFadeScreen);
  SCREEN_CHK_SIZE(lpstSourceScreen, lpstFadeScreen);


  if (lpstFadeScreen->ui16Width<lpstSourceScreen->ui16Width) li32x2 = lpstFadeScreen->ui16Width;
                                                        else li32x2 = lpstSourceScreen->ui16Width;
  if (lpstFadeScreen->ui16Height<lpstSourceScreen->ui16Height) li32y2 = lpstFadeScreen->ui16Height;
                                                          else li32y2 = lpstSourceScreen->ui16Height;

  for (li32x1 = 0; li32x1 < li32x2; li32x1++)
  {
    for (li32y1 = 0; li32y1 < li32y2; li32y1++)
    {
      li32Fcol = BPP32_8R8G8B_PXL(li32x1, li32y1, lpstFadeScreen);
      li32Scol = BPP32_8R8G8B_PXL(li32x1, li32y1, lpstSourceScreen);

      if (li32Fcol != li32Scol)
      {
        *li32Ready = 0;

        BPP32_8R8G8B_GET_RGB(li32Fcol, li32Fr, li32Fg, li32Fb)
        BPP32_8R8G8B_GET_RGB(li32Scol, li32Sr, li32Sg, li32Sb)

        if  (li32Fr != li32Sr)
        {
          if (li32Fr > li32Sr + li32Speed) 
          {
            li32Fr-=li32Speed;
          }
          else
          {
            if (li32Fr + li32Speed < li32Sr) li32Fr+= li32Speed;
                                        else li32Fr = li32Sr;
          }
        }

        if  (li32Fg != li32Sg)
        {
          if (li32Fg > li32Sg + li32Speed) 
          {
            li32Fg -= li32Speed;
          }
          else
          {
            if (li32Fg + li32Speed < li32Sg) li32Fg +=li32Speed;
                                        else li32Fg  =li32Sg;
          }
        }

        if  (li32Fb != li32Sb)
        {
          if (li32Fb > li32Sb + li32Speed) 
          {
            li32Fb -= li32Speed;
          }
          else
          {
            if (li32Fb + li32Speed < li32Sb) li32Fb += li32Speed;
                                        else li32Fb  = li32Sb;
          }
        }
      
        BPP32_8R8G8B_PXL(li32x1, li32y1, lpstFadeScreen) = BPP32_8R8G8B_RGB(li32Fr, li32Fg, li32Fb);
      }
    }
  }

  return 0;
}
   
int8 BPP32_8R8G8B_CopyScreenRaw(Screen* lpstSourceScreen, Screen* lpstDestScreen)
{
  uint32 li32x1=0, li32x2=0;
  uint32 li32y1=0, li32y2, lui32yy1, lui32yy2;

	int32 *lpstDest    = (int32*)lpstDestScreen->paui8Screen;
	int32 *lpstSource  = (int32*)lpstSourceScreen->paui8Screen;

	int32 li32sWidth   = lpstSourceScreen->ui16Width;  
	int32 li32dWidth   = lpstDestScreen->ui16Width;  
  
  SCREEN_CHK_INIT(lpstSourceScreen);
  BPP32_8R8G8B_CHECK(lpstSourceScreen);
  SCREEN_CHK_INIT(lpstDestScreen);
  BPP32_8R8G8B_CHECK(lpstDestScreen);

  if (lpstDestScreen->ui8In_Use != false)
  {
    if (lpstDestScreen->ui16Width < lpstSourceScreen->ui16Width) li32x2 = lpstDestScreen->ui16Width;
                                                        else li32x2 = lpstSourceScreen->ui16Width;
    if (lpstDestScreen->ui16Height < lpstSourceScreen->ui16Height) li32y2 = lpstDestScreen->ui16Height;
                                                          else li32y2 = lpstSourceScreen->ui16Height;

	  lui32yy2=lui32yy1=0;
						  
    if (lpstSourceScreen->ui8Type == lpstDestScreen->ui8Type)
	  {
	  #ifdef VC_ASM_CODE
	    int32 li32sWidth4x = li32sWidth * 4;  
	    int32 li32dWidth4x = li32dWidth * 4;
	    __asm
	    {
		    cld
        mov ecx,li32y2
		    mov esi, lpstSource
		    mov edi, lpstDest

		    L11:
		      push esi
  		    push edi
		      push ecx
          
	        mov ecx,li32x2
		    
          L12:
			      lodsd
		        stosd
		      Loop L12 			    

		      pop ecx
		      pop edi
	        pop esi
		      
		      add edi,li32dWidth4x
		      add esi,li32sWidth4x

		    Loop L11
	    }
	  #else
		  for (li32y1 = 0; li32y1 < li32y2; li32y1++)
		  {				
		    for (li32x1 = 0; li32x1 < li32x2; li32x1++)
		    {					 
			    lpstDest[lui32yy1 + li32x1] = lpstSource[lui32yy2 + li32x1];
		    }
        lui32yy1 += li32dWidth;
		    lui32yy2 += li32sWidth;
		  }
	  #endif
	  }
  }
  else
  {
    return 2;
  }
  return 0;
}

int8 BPP32_8R8G8B_SubScreen(Screen* lpstSourceScreen1, int32 li32Percent1, int32 ui32TransCol1,
                            Screen* lpstSourceScreen2, int32 li32Percent2, int32 ui32TransCol2,
                            Screen* lpstDestScreen)
{
  int32 li32Fr,li32Fb,li32Fg;
  int32 li32Fcol;
  int32 li32Sr,li32Sb,li32Sg;
  int32 li32Scol;

  uint32 li32x1,li32x2;
  uint32 li32y1,li32y2;

  SCREEN_CHK_INIT(lpstSourceScreen1);
  BPP32_8R8G8B_CHECK(lpstSourceScreen1);
  SCREEN_CHK_INIT(lpstSourceScreen2);
  BPP32_8R8G8B_CHECK(lpstSourceScreen2);
  SCREEN_CHK_SIZE(lpstSourceScreen1, lpstSourceScreen2);

  if (SCREEN_CLONE(lpstSourceScreen1, lpstDestScreen) == 0)
  {
    if (lpstDestScreen->ui16Width<lpstSourceScreen1->ui16Width) li32x2=lpstDestScreen->ui16Width;
                                      else li32x2=lpstSourceScreen1->ui16Width;
    if (lpstDestScreen->ui16Height<lpstSourceScreen1->ui16Height) li32y2=lpstDestScreen->ui16Height;
                                        else li32y2=lpstSourceScreen1->ui16Height;

    if (lpstSourceScreen2->ui16Width<li32x2)  li32x2=lpstSourceScreen2->ui16Width;
    if (lpstSourceScreen2->ui16Height<li32y2) li32y2=lpstSourceScreen2->ui16Height;

    for (li32x1 = 0; li32x1 < li32x2; li32x1++)
    {
      for (li32y1 = 0; li32y1 < li32y2; li32y1++)
      {

        li32Fcol = BPP32_8R8G8B_PXL(li32x1, li32y1, lpstSourceScreen1);
        li32Scol = BPP32_8R8G8B_PXL(li32x1, li32y1, lpstSourceScreen2);


        BPP32_8R8G8B_GET_RGB(li32Fcol, li32Fr, li32Fg, li32Fb)
        BPP32_8R8G8B_GET_RGB(li32Scol, li32Sr, li32Sg, li32Sb)

        if (li32Fcol == ui32TransCol1)
        {
          li32Fr = 0;
          li32Fg = 0;
          li32Fb = 0;
        }

        if (li32Scol == ui32TransCol2)
        {
          li32Sr = 0;
          li32Sg = 0;
          li32Sb = 0;
        }

        li32Sr = li32Sr * li32Percent2 / 100 - li32Fr * li32Percent1 / 100;
        li32Sg = li32Sg * li32Percent2 / 100 - li32Fg * li32Percent1 / 100;
        li32Sb = li32Sb * li32Percent2 / 100 - li32Fb * li32Percent1 / 100;

        if (li32Sr < 0) li32Sr = 0;
        if (li32Sg < 0) li32Sg = 0;
        if (li32Sb < 0) li32Sb = 0;


        BPP32_8R8G8B_PXL(li32x1, li32y1, lpstDestScreen) = BPP32_8R8G8B_RGB(li32Sr, li32Sg, li32Sb);
      }
    }
  }
  else
  {
    return 2;
  }
  return 0;
}

int8 BPP32_8R8G8B_AddValue(int32 li32Value, Screen* lpstSourceScreen, Screen* lpstDestScreen)
{
  int32  li32t,li32r,li32b,li32g;
  uint32 lui32Col;

  SCREEN_CHK_INIT(lpstSourceScreen);
  BPP32_8R8G8B_CHECK(lpstSourceScreen);
  if (SCREEN_CLONE(lpstSourceScreen, lpstDestScreen) == 0)
  {
    for (li32t = 0; li32t < SCREEN_SIZE(lpstSourceScreen); li32t++)
    {
      lui32Col = BPP32_8R8G8B_MEM(li32t, lpstSourceScreen);

      BPP32_8R8G8B_GET_RGB(lui32Col, li32r, li32g, li32b)
        
      li32r += li32Value; li32r %= 256;
      li32g += li32Value; li32g %= 256;
      li32b += li32Value; li32b %= 256;

      BPP32_8R8G8B_MEM(li32t, lpstDestScreen) = BPP32_8R8G8B_RGB(li32r, li32g, li32b);
    }
  }
  else
  {
    return 2;
  }
  return 0;
}

int8 BPP32_8R8G8B_AddScreen(Screen* lpstSourceScreen1, int32 li32Percent1, int32 lui32TransCol1,
                            Screen* lpstSourceScreen2, int32 li32Percent2, int32 lui32TransCol2,
                            Screen* lpstDestScreen)
{
  int32 li32Fr,li32Fb,li32Fg;
  int32 li32Fcol;
  int32 li32Sr,li32Sb,li32Sg;
  int32 li32Scol;

  uint32 li32x1,li32x2;
  uint32 li32y1,li32y2;

  SCREEN_CHK_INIT(lpstSourceScreen1);
  BPP32_8R8G8B_CHECK(lpstSourceScreen1);
  SCREEN_CHK_INIT(lpstSourceScreen2);
  BPP32_8R8G8B_CHECK(lpstSourceScreen2);

  if (SCREEN_CLONE(lpstSourceScreen1, lpstDestScreen) == 0)
  {
    if (lpstDestScreen->ui16Width < lpstSourceScreen1->ui16Width) li32x2 = lpstDestScreen->ui16Width;
                                                           else li32x2 = lpstSourceScreen1->ui16Width;
    if (lpstDestScreen->ui16Height < lpstSourceScreen1->ui16Height) li32y2 = lpstDestScreen->ui16Height;
                                                             else li32y2 = lpstSourceScreen1->ui16Height;

    if (lpstSourceScreen2->ui16Width < li32x2)  li32x2 = lpstSourceScreen2->ui16Width;
    if (lpstSourceScreen2->ui16Height < li32y2) li32y2 = lpstSourceScreen2->ui16Height;

    if ((li32Percent1 == li32Percent2) && (li32Percent1 == 50))
    {
      for (li32x1 = 0; li32x1 < li32x2; li32x1++)
      {
        for (li32y1 = 0; li32y1 < li32y2; li32y1++)
        {
          li32Fcol = BPP32_8R8G8B_PXL(li32x1, li32y1, lpstSourceScreen1);
          li32Scol = BPP32_8R8G8B_PXL(li32x1, li32y1, lpstSourceScreen2);

          BPP32_8R8G8B_GET_RGB(li32Fcol, li32Fr, li32Fg, li32Fb)
          if (li32Fcol == lui32TransCol1)
          {
            li32Fr = 0;
            li32Fg = 0;
            li32Fb = 0;
          }

          BPP32_8R8G8B_GET_RGB(li32Scol, li32Sr, li32Sg, li32Sb)
          if (li32Fcol == lui32TransCol2)
          {
            li32Sr = 0;
            li32Sg = 0;
            li32Sb = 0;
          }

          li32Sr = (li32Sr + li32Fr) >> 1;
          li32Sg = (li32Sg + li32Fg) >> 1;
          li32Sb = (li32Sb + li32Fb) >> 1;

          BPP32_8R8G8B_PXL(li32x1, li32y1, lpstDestScreen) = BPP32_8R8G8B_RGB(li32Sr, li32Sg, li32Sb);
        }
      }
    }
    else
    {
      for (li32x1 = 0; li32x1 < li32x2; li32x1++)
      {
        for (li32y1 = 0; li32y1 < li32y2; li32y1++)
        {
          li32Fcol = BPP32_8R8G8B_PXL(li32x1, li32y1, lpstSourceScreen1);
          li32Scol = BPP32_8R8G8B_PXL(li32x1, li32y1, lpstSourceScreen2);


          BPP32_8R8G8B_GET_RGB(li32Scol, li32Sr, li32Sg, li32Sb)
          if (li32Fcol == lui32TransCol1)
          {
            li32Sr = 0;
            li32Sg = 0;
            li32Sb = 0;
          }

          BPP32_8R8G8B_GET_RGB(li32Fcol, li32Fr, li32Fg, li32Fb)
          if (li32Fcol == lui32TransCol2)
          {
            li32Fr = 0;
            li32Fg = 0;
            li32Fb = 0;
          }

          li32Sr = li32Sr * li32Percent2 / 100 + li32Fr * li32Percent1 / 100;
          li32Sg = li32Sg * li32Percent2 / 100 + li32Fg * li32Percent1 / 100;
          li32Sb = li32Sb * li32Percent2 / 100 + li32Fb * li32Percent1 / 100;
 
          if (li32Sr > 255) li32Sr = 255;
          if (li32Sg > 255) li32Sg = 255;
          if (li32Sb > 255) li32Sb = 255;

          BPP32_8R8G8B_PXL(li32x1, li32y1, lpstDestScreen) = BPP32_8R8G8B_RGB(li32Sr, li32Sg, li32Sb);
        }
      }
    }
  }
  else
  {
    return 2;
  }
  return 0;
}

int8 BPP32_8R8G8B_InterpolX(Screen* lpstSourceScreen, Screen* lpstDestScreen)
{
  int32 li32Er, li32Eb, li32Eg;
  int32 li32Ecol;
  int32 li32Sr,li32Sb,li32Sg;
  int32 li32SrAdd,li32SbAdd,li32SgAdd;
  int32 li32Scol;

  int32 li32x1,li32x2;
  int32 li32y1,li32y2;

  int32 li32t;

  int32 li32XStart;
  int32 li32XEnd;

  li32x2 = lpstSourceScreen->ui16Width;
  li32y2 = lpstSourceScreen->ui16Height;

  SCREEN_CHK_INIT(lpstSourceScreen);
  BPP32_8R8G8B_CHECK(lpstSourceScreen);

  if (SCREEN_CLONE(lpstSourceScreen, lpstDestScreen) == 0)
  {
    li32y1 = 0;
    while (li32y1 < li32y2)
    {
        li32x1=0;
      while (li32x1 < li32x2 - 1)
      {

        li32Scol = BPP32_8R8G8B_PXL(li32x1,     li32y1, lpstSourceScreen);
        li32Ecol = BPP32_8R8G8B_PXL(li32x1 + 1, li32y1, lpstSourceScreen);

        li32XStart = li32x1;
        li32XEnd   = li32x1+1;

        while ((li32Scol == li32Ecol) && (li32XEnd < li32x2 - 1))
        {
           li32XEnd++;           
           li32Ecol = BPP32_8R8G8B_PXL(li32XEnd, li32y1, lpstSourceScreen);
        }

        if ((li32XStart + 1 < li32XEnd) && (li32Ecol != li32Scol))
        {
          BPP32_8R8G8B_GET_RGB(li32Ecol, li32Er, li32Eg, li32Eb);

          li32Er = li32Er << 8;
          li32Eg = li32Eg << 8;
          li32Eb = li32Eb << 8;

          BPP32_8R8G8B_GET_RGB(li32Scol, li32Sr, li32Sg, li32Sb);

          li32Sr = li32Sr << 8;
          li32Sg = li32Sg << 8;
          li32Sb = li32Sb << 8;

          li32SrAdd = (li32Er - li32Sr) / (li32XEnd - li32XStart);
          li32SgAdd = (li32Eg - li32Sg) / (li32XEnd - li32XStart);
          li32SbAdd = (li32Eb - li32Sb) / (li32XEnd - li32XStart);

          for (li32t = li32XStart; li32t <= li32XEnd; li32t++)
          {
            li32Sr += li32SrAdd;
            li32Sg += li32SgAdd;
            li32Sb += li32SbAdd;

            if (li32Sr > 65535) li32Sr = 65535;
            if (li32Sg > 65535) li32Sg = 65535;
            if (li32Sb > 65535) li32Sb = 65535;

            if (li32Sr<0) li32Sr = 0;
            if (li32Sg<0) li32Sg = 0;
            if (li32Sb<0) li32Sb = 0;

            BPP32_8R8G8B_PXL(li32t, li32y1, lpstDestScreen) = BPP32_8R8G8B_RGB((li32Sr >> 8), (li32Sg >> 8), (li32Sb >> 8));
          }

        }
        li32x1 = li32XEnd;
      }
      li32y1++;
    }
  }
  else
  {
    return 2;
  }
  return 0;
}

int8 BPP32_8R8G8B_InterpolY(Screen* lpstSourceScreen, Screen* lpstDestScreen)
{
  int32 li32Er,li32Eb,li32Eg;
  int32 li32Ecol;
  int32 li32Sr,li32Sb,li32Sg;
  int32 li32SrAdd,li32SbAdd,li32SgAdd;
  int32 li32Scol;

  int32 li32x1,li32x2;
  int32 li32y1,li32y2;

  int32 li32t;

  int32 YStart;
  int32 YEnd;

  SCREEN_CHK_INIT(lpstSourceScreen);
  BPP32_8R8G8B_CHECK(lpstSourceScreen);
  if (SCREEN_CLONE(lpstSourceScreen, lpstDestScreen) == 0)
  {
    li32x2 = lpstSourceScreen->ui16Width;
    li32y2 = lpstSourceScreen->ui16Height;

    li32x1 = 0;
    while (li32x1 < li32x2)
    {
      li32y1 = 0;
      while (li32y1 < li32y2 - 1)
      {
        li32Scol = BPP32_8R8G8B_PXL(li32x1,  li32y1,      lpstSourceScreen);
        li32Ecol = BPP32_8R8G8B_PXL(li32x1, (li32y1 + 1), lpstSourceScreen);
        
        YStart = li32y1;
        YEnd   = li32y1 + 1;

        while ((li32Scol == li32Ecol) && (YEnd < li32y2 - 1))
        {
           YEnd++;           
           li32Ecol = BPP32_8R8G8B_PXL(li32x1, YEnd, lpstSourceScreen);
        }

        if ((YStart + 1 < YEnd) && (li32Ecol != li32Scol))
        {
         
          BPP32_8R8G8B_GET_RGB(li32Ecol, li32Er, li32Eg, li32Eb);
          li32Er = li32Er << 8;
          li32Eg = li32Eg << 8;
          li32Eb = li32Eb << 8;

          BPP32_8R8G8B_GET_RGB(li32Scol, li32Sr, li32Sg, li32Sb);
          li32Sr = li32Sr << 8;
          li32Sg = li32Sg << 8;
          li32Sb = li32Sb << 8;

          li32SrAdd = (li32Er - li32Sr) / (YEnd - YStart);
          li32SgAdd = (li32Eg - li32Sg) / (YEnd - YStart);
          li32SbAdd = (li32Eb - li32Sb) / (YEnd - YStart);

          for (li32t = YStart; li32t <= YEnd; li32t++)
          {
            li32Sr += li32SrAdd;
            li32Sg += li32SgAdd;
            li32Sb += li32SbAdd;

            if (li32Sr > 65535) li32Sr = 65535;
            if (li32Sg > 65535) li32Sg = 65535;
            if (li32Sb > 65535) li32Sb = 65535;

            if (li32Sr < 0) li32Sr = 0;
            if (li32Sg < 0) li32Sg = 0;
            if (li32Sb < 0) li32Sb = 0;
                        
            BPP32_8R8G8B_PXL(li32x1, li32t, lpstDestScreen) = BPP32_8R8G8B_RGB((li32Sr >> 8), (li32Sg >> 8), (li32Sb >> 8));
          }

        }
        li32y1=YEnd;
      }
      li32x1++;
    }
  }
  else
  {
    return 2;
  }
  return 0;
}

int8 BPP32_8R8G8B_InterpolX_Seem(Screen* lpstSourceScreen,Screen* lpstDestScreen)
{
  int32 li32Er, li32Eb, li32Eg;
  int32 li32Ecol;
  int32 li32Sr, li32Sb, li32Sg;
  int32 li32SrAdd, li32SbAdd, li32SgAdd;
  int32 li32Scol;

  int32 li32x1,li32x2;
  int32 li32y1,li32y2;

  int32 li32t;

  int32 li32XStart;
  int32 li32XEnd;

  SCREEN_CHK_INIT(lpstSourceScreen);
  BPP32_8R8G8B_CHECK(lpstSourceScreen);
  if (SCREEN_CLONE(lpstSourceScreen, lpstDestScreen) == 0)
  {
    li32x2 = lpstSourceScreen->ui16Width + 1;
    li32y2 = lpstSourceScreen->ui16Height;

    li32y1 = 0;
    while (li32y1 < li32y2)
    {
      li32x1=0;
      while (li32x1 < li32x2)
      {
        li32Scol = BPP32_8R8G8B_PXL( (li32x1      % lpstSourceScreen->ui16Width), li32y1, lpstSourceScreen);
        li32Ecol = BPP32_8R8G8B_PXL(((li32x1 + 1) % lpstSourceScreen->ui16Width), li32y1, lpstSourceScreen);


        li32XStart = li32x1;
        li32XEnd   = li32x1 + 1;

        while ((li32Scol == li32Ecol) && (li32XEnd < li32x2 - 1))
        {
           li32XEnd++;
           li32Ecol = BPP32_8R8G8B_PXL((li32XEnd % lpstSourceScreen->ui16Width), li32y1, lpstSourceScreen);
        }

        if ((li32XStart + 1 < li32XEnd) && (li32Ecol != li32Scol))
        {
          BPP32_8R8G8B_GET_RGB(li32Ecol, li32Er, li32Eg, li32Eb);
          li32Er = li32Er << 8;
          li32Eg = li32Eg << 8;
          li32Eb = li32Eb << 8;

          BPP32_8R8G8B_GET_RGB(li32Scol, li32Sr, li32Sg, li32Sb);
          li32Sr = li32Sr << 8;
          li32Sg = li32Sg << 8;
          li32Sb = li32Sb << 8;

          li32SrAdd = (li32Er - li32Sr) / (li32XEnd - li32XStart);
          li32SgAdd = (li32Eg - li32Sg) / (li32XEnd - li32XStart);
          li32SbAdd = (li32Eb - li32Sb) / (li32XEnd - li32XStart);

          for (li32t = li32XStart; li32t <= li32XEnd; li32t++)
          {
            li32Sr += li32SrAdd;
            li32Sg += li32SgAdd;
            li32Sb += li32SbAdd;

            if (li32Sr > 65535) li32Sr = 65535;
            if (li32Sg > 65535) li32Sg = 65535;
            if (li32Sb > 65535) li32Sb = 65535;

            if (li32Sr < 0) li32Sr = 0;
            if (li32Sg < 0) li32Sg = 0;
            if (li32Sb < 0) li32Sb = 0;
            
            BPP32_8R8G8B_PXL((li32t % lpstDestScreen->ui16Width), li32y1, lpstDestScreen) = BPP32_8R8G8B_RGB((li32Sr >> 8), (li32Sg >> 8), (li32Sb >> 8));
          }
        }
        li32x1 = li32XEnd;
      }
      li32y1++;
    }
  }
  else
  {
    return 2;
  }
  return 0;
}


int8 BPP32_8R8G8B_InterpolXY_Seem(Screen* lpstSourceScreen,Screen* lpstDestScreen)
{
  uint32 lui32Col;
  int32 li32r1,li32b1,li32g1;
  int32 li32r[5]; 
  int32 li32b[5]; 
  int32 li32g[5]; 

  uint32 li32x1,li32x2;
  uint32 li32y1,li32y2;

  SCREEN_CHK_INIT(lpstSourceScreen);
  BPP32_8R8G8B_CHECK(lpstSourceScreen);
  if (SCREEN_CLONE(lpstSourceScreen, lpstDestScreen) == 0)
  {
    li32x2=lpstSourceScreen->ui16Width;
    li32y2=lpstSourceScreen->ui16Height;

    for (li32x1 = 0; li32x1 < li32x2; li32x1++)
    {
      for (li32y1 = 0; li32y1 < li32y2; li32y1++)
      {    
        lui32Col = BPP32_8R8G8B_PXL((li32x1 % lpstSourceScreen->ui16Width), li32y1, lpstSourceScreen);
        BPP32_8R8G8B_GET_RGB(lui32Col, li32r[0], li32g[0], li32b[0]);

        lui32Col = BPP32_8R8G8B_PXL((li32x1 % lpstSourceScreen->ui16Width), ((li32y1 + 1 + lpstSourceScreen->ui16Height) % lpstSourceScreen->ui16Height), lpstSourceScreen);
        BPP32_8R8G8B_GET_RGB(lui32Col, li32r[1], li32g[1], li32b[1]);

        lui32Col = BPP32_8R8G8B_PXL((li32x1 % lpstSourceScreen->ui16Width), ((li32y1 - 1 + lpstSourceScreen->ui16Height) % lpstSourceScreen->ui16Height), lpstSourceScreen);      
        BPP32_8R8G8B_GET_RGB(lui32Col, li32r[2], li32g[2], li32b[2]);

        lui32Col = BPP32_8R8G8B_PXL(((li32x1 + 1 + lpstSourceScreen->ui16Width) % lpstSourceScreen->ui16Width), li32y1, lpstSourceScreen);      
        BPP32_8R8G8B_GET_RGB(lui32Col, li32r[3], li32g[3], li32b[3]);

        lui32Col = BPP32_8R8G8B_PXL(((li32x1 - 1 + lpstSourceScreen->ui16Width) % lpstSourceScreen->ui16Width), li32y1, lpstSourceScreen);      
        BPP32_8R8G8B_GET_RGB(lui32Col, li32r[4], li32g[4], li32b[4]);

        li32b1 = (li32b[0] + li32b[1] + li32b[2] + li32b[3] + li32b[4]) / 5;
        li32g1 = (li32g[0] + li32g[1] + li32g[2] + li32g[3] + li32g[4]) / 5;
        li32r1 = (li32r[0] + li32r[1] + li32r[2] + li32r[3] + li32r[4]) / 5;
      
        BPP32_8R8G8B_PXL(li32x1, li32y1, lpstDestScreen) = BPP32_8R8G8B_RGB(li32r1, li32g1, li32b1);
      }
    }
  }
  else
  {
    return 2;
  }
  return 0;
}

int8 BPP32_8R8G8B_InterpolY_Seem(Screen* lpstSourceScreen, Screen* lpstDestScreen)
{
  int32 li32Er,li32Eb,li32Eg;
  int32 li32Ecol;
  int32 li32Sr,li32Sb,li32Sg;
  int32 li32SrAdd,li32SbAdd,li32SgAdd;
  int32 li32Scol;

  int32 li32x1, li32x2;
  int32 li32y1, li32y2;

  int32 li32t;

  int32 YStart;
  int32 YEnd;


  SCREEN_CHK_INIT(lpstSourceScreen);
  BPP32_8R8G8B_CHECK(lpstSourceScreen);
  if (SCREEN_CLONE(lpstSourceScreen, lpstDestScreen) == 0)
  {

    li32x2 = lpstSourceScreen->ui16Width;
    li32y2 = lpstSourceScreen->ui16Height + 1;

    li32x1=0;
    while (li32x1 < li32x2)
    {
      li32y1=0;
      while (li32y1 < li32y2)
      {
        li32Scol = BPP32_8R8G8B_PXL(li32x1, (li32y1    % lpstSourceScreen->ui16Height), lpstSourceScreen);
        li32Ecol = BPP32_8R8G8B_PXL(li32x1, ((li32y1+1) % lpstSourceScreen->ui16Height), lpstSourceScreen);

        YStart = li32y1;
        YEnd   = li32y1 + 1;

        while ((li32Scol == li32Ecol) && (YEnd < li32y2 - 1))
        {
           YEnd++;
           li32Ecol = BPP32_8R8G8B_PXL(li32x1, (YEnd % lpstSourceScreen->ui16Height), lpstSourceScreen);
        }

        if (( YStart + 1 < YEnd) && (li32Ecol != li32Scol))
        {
          BPP32_8R8G8B_GET_RGB(li32Ecol, li32Er, li32Eg, li32Eb);
          li32Er = li32Er << 8;
          li32Eg = li32Eg << 8;
          li32Eb = li32Eb << 8;

          BPP32_8R8G8B_GET_RGB(li32Scol, li32Sr, li32Sg, li32Sb);
          li32Sr = li32Sr << 8;
          li32Sg = li32Sg << 8;
          li32Sb = li32Sb << 8;

          li32SrAdd = (li32Er - li32Sr) / (YEnd - YStart);
          li32SgAdd = (li32Eg - li32Sg) / (YEnd - YStart);
          li32SbAdd = (li32Eb - li32Sb) / (YEnd - YStart);

          for (li32t = YStart; li32t<= YEnd; li32t++)
          {
            li32Sr += li32SrAdd;
            li32Sg += li32SgAdd;
            li32Sb += li32SbAdd;

            if (li32Sr > 65535) li32Sr = 65535;
            if (li32Sg > 65535) li32Sg = 65535;
            if (li32Sb > 65535) li32Sb = 65535;

            if (li32Sr < 0) li32Sr = 0;
            if (li32Sg < 0) li32Sg = 0;
            if (li32Sb < 0) li32Sb = 0;

            BPP32_8R8G8B_PXL(li32x1, (li32t % lpstDestScreen->ui16Height), lpstDestScreen) = BPP32_8R8G8B_RGB((li32Sr >> 8), (li32Sg >> 8), (li32Sb >> 8));
          }

        }
        li32y1 = YEnd;
      }
      li32x1++;
    }
  }
  else
  {
    return 2;
  }
  return 0;
}

int8 BPP32_8R8G8B_ScrolllScreen(uint32 lui32Xadd, uint32 lui32Yadd,  Screen *lpstSourceScreen, Screen *lpstDestScreen)
{
  uint32 lui32x, lui32y, lui32col;

  SCREEN_CHK_INIT(lpstSourceScreen);
  BPP32_8R8G8B_CHECK(lpstSourceScreen);
  if (SCREEN_CLONE(lpstSourceScreen, lpstDestScreen) == 0)
  {
    if (lui32Xadd < 0) lui32Xadd = (lui32Xadd) % lpstSourceScreen->ui16Height;
    if (lui32Yadd < 0) lui32Yadd = (lui32Yadd) % lpstSourceScreen->ui16Height;

    for (lui32x = 0; lui32x < lpstSourceScreen->ui16Width; lui32x++)
    {
      for (lui32y = 0; lui32y < lpstSourceScreen->ui16Height; lui32y++)
      {
        lui32col = BPP32_8R8G8B_PXL(lui32x, lui32y, lpstSourceScreen);      
        BPP32_8R8G8B_PXL((lui32x + lui32Xadd) % lpstSourceScreen->ui16Width, ((lui32y + lui32Yadd) % lpstSourceScreen->ui16Height), lpstSourceScreen) = lui32col;
      }
    }
  }
  else
  {
    return 2;
  }
  return 0;
}

int8 BPP32_8R8G8B_ANDValue(uint32 lui32Value, Screen *lpstSourceScreen, Screen *lpstDestScreen)
{
  int32 li32t;

  SCREEN_CHK_INIT(lpstSourceScreen);
  BPP32_8R8G8B_CHECK(lpstSourceScreen);

  if (SCREEN_CLONE(lpstSourceScreen, lpstDestScreen) == 0)
  {
    for (li32t = 0; li32t < SCREEN_SIZE(lpstDestScreen); li32t++)
    {
      BPP32_8R8G8B_MEM(li32t, lpstDestScreen) = BPP32_8R8G8B_MEM(li32t, lpstDestScreen) & (lui32Value & 0x0FFFFFF);
    }
  }
  else
  {
    return 2;
  }

  return 0;
}

int8 BPP32_8R8G8B_ORValue(uint32 lui32Value, Screen *lpstSourceScreen, Screen *lpstDestScreen)
{
  int32 li32t;

  SCREEN_CHK_INIT(lpstSourceScreen);
  BPP32_8R8G8B_CHECK(lpstSourceScreen);

  if (SCREEN_CLONE(lpstSourceScreen, lpstDestScreen) == 0)
  {
    for (li32t = 0; li32t < SCREEN_SIZE(lpstDestScreen); li32t++)
    {
      BPP32_8R8G8B_MEM(li32t, lpstDestScreen) = BPP32_8R8G8B_MEM(li32t, lpstDestScreen) | (lui32Value & 0x0FFFFFF);
    }
  }
  else
  {
    return 2;
  }

  return 0;
}

int8 BPP32_8R8G8B_XORValue(uint32 lui32Value, Screen* lpstSourceScreen, Screen* lpstDestScreen)
{
  int32 li32t;

  SCREEN_CHK_INIT(lpstSourceScreen);
  BPP32_8R8G8B_CHECK(lpstSourceScreen);

  if (SCREEN_CLONE(lpstSourceScreen, lpstDestScreen) == 0)
  {
    for (li32t = 0; li32t < SCREEN_SIZE(lpstDestScreen); li32t++)
    {
      BPP32_8R8G8B_MEM(li32t, lpstDestScreen) = BPP32_8R8G8B_MEM(li32t, lpstDestScreen) ^ (lui32Value & 0x0FFFFFF);
    }
  }
  else
  {
    return 2;
  }

  return 0;
}

int8 BPP32_8R8G8B_NOTScreen(Screen* lpstSourceScreen, Screen* lpstDestScreen)
{
  int32 li32t;

  SCREEN_CHK_INIT(lpstSourceScreen);
  BPP32_8R8G8B_CHECK(lpstSourceScreen);

  if (SCREEN_CLONE(lpstSourceScreen, lpstDestScreen) == 0)
  {
    for (li32t = 0; li32t < SCREEN_SIZE(lpstDestScreen); li32t++)
    {
      BPP32_8R8G8B_MEM(li32t, lpstDestScreen) = (~BPP32_8R8G8B_MEM(li32t, lpstSourceScreen)) & 0x0FFFFFF;
    }
  }
  else
  {
    return 2;
  }
  return 0;
}

int8 BPP32_8R8G8B_RGB_NEGScreen(Screen* lpstSourceScreen, Screen* lpstDestScreen)
{
  int32 li32t;
  uint32 lui32col;
  uint32 lui32r,lui32g,lui32b;

  SCREEN_CHK_INIT(lpstSourceScreen);
  BPP32_8R8G8B_CHECK(lpstSourceScreen);

  if (SCREEN_CLONE(lpstSourceScreen, lpstDestScreen) == 0)
  {
    for (li32t = 0; li32t < SCREEN_SIZE(lpstDestScreen); li32t++)
    {
      lui32col = BPP32_8R8G8B_MEM(li32t, lpstSourceScreen);

      BPP32_8R8G8B_GET_RGB(lui32col, lui32r, lui32g, lui32b);

      lui32r = 255 - lui32r;
      lui32g = 255 - lui32g;
      lui32b = 255 - lui32b;

      lui32col = BPP32_8R8G8B_RGB(lui32r, lui32g, lui32b); 

      BPP32_8R8G8B_MEM(li32t, lpstDestScreen) = lui32col;
    }
  }
  else
  {
    return 2;
  }
  return 0;
}

int8 BPP32_8R8G8B_ANDScreen(Screen* lpstSourceScreen1, 
                            Screen* lpstSourceScreen2,
                            Screen* lpstDestScreen)
{
  int32 li32t;

  SCREEN_CHK_INIT(lpstSourceScreen1);
  BPP32_8R8G8B_CHECK(lpstSourceScreen1);
  SCREEN_CHK_INIT(lpstSourceScreen2);
  BPP32_8R8G8B_CHECK(lpstSourceScreen2);
  SCREEN_CHK_SIZE(lpstSourceScreen1, lpstSourceScreen2);

  if (SCREEN_CLONE(lpstSourceScreen1, lpstDestScreen) == 0)
  {
    for (li32t = 0; li32t < SCREEN_SIZE(lpstDestScreen); li32t++)
    {
      BPP32_8R8G8B_MEM(li32t, lpstDestScreen)  = BPP32_8R8G8B_MEM(li32t, lpstSourceScreen1) & BPP32_8R8G8B_MEM(li32t, lpstSourceScreen2);
      BPP32_8R8G8B_MEM(li32t, lpstDestScreen) &= 0x0FFFFFF;
    }
  }
  else
  {
    return 2;
  }
  return 0;
}

int8 BPP32_8R8G8B_ORScreen(Screen* lpstSourceScreen1, 
                           Screen* lpstSourceScreen2,
                           Screen* lpstDestScreen)
{
  int32 li32t;

  SCREEN_CHK_INIT(lpstSourceScreen1);
  BPP32_8R8G8B_CHECK(lpstSourceScreen1);
  SCREEN_CHK_INIT(lpstSourceScreen2);
  BPP32_8R8G8B_CHECK(lpstSourceScreen2);
  SCREEN_CHK_SIZE(lpstSourceScreen1, lpstSourceScreen2);

  if (SCREEN_CLONE(lpstSourceScreen1, lpstDestScreen) == 0)
  {
    for (li32t = 0; li32t < SCREEN_SIZE(lpstDestScreen); li32t++)
    {
      BPP32_8R8G8B_MEM(li32t, lpstDestScreen)  = BPP32_8R8G8B_MEM(li32t, lpstSourceScreen1) | BPP32_8R8G8B_MEM(li32t, lpstSourceScreen2);
      BPP32_8R8G8B_MEM(li32t, lpstDestScreen) &= 0x0FFFFFF;
    }
  }
  else
  {
    return 2;
  }
  return 0;
}

int8 BPP32_8R8G8B_XORScreen(Screen* lpstSourceScreen1, 
                            Screen* lpstSourceScreen2,
                            Screen* lpstDestScreen)
{
  int32 li32t;

  SCREEN_CHK_INIT(lpstSourceScreen1);
  BPP32_8R8G8B_CHECK(lpstSourceScreen1);
  SCREEN_CHK_INIT(lpstSourceScreen2);
  BPP32_8R8G8B_CHECK(lpstSourceScreen2);
  SCREEN_CHK_SIZE(lpstSourceScreen1, lpstSourceScreen2);

  if (SCREEN_CLONE(lpstSourceScreen1, lpstDestScreen) == 0)
  {
    for (li32t = 0; li32t < SCREEN_SIZE(lpstDestScreen); li32t++)
    {
      BPP32_8R8G8B_MEM(li32t, lpstDestScreen)  = BPP32_8R8G8B_MEM(li32t, lpstSourceScreen1) ^ BPP32_8R8G8B_MEM(li32t, lpstSourceScreen2);
      BPP32_8R8G8B_MEM(li32t, lpstDestScreen) &= 0x0FFFFFF;
    }
  }
  else
  {
    return 2;
  }
  return 0;
}


int8 BPP32_8R8G8B_MAXScreen(Screen* lpstSourceScreen1, 
                            Screen* lpstSourceScreen2,
                            Screen* lpstDestScreen)
{
  int32 li32t;

  SCREEN_CHK_INIT(lpstSourceScreen1);
  BPP32_8R8G8B_CHECK(lpstSourceScreen1);
  SCREEN_CHK_INIT(lpstSourceScreen2);
  BPP32_8R8G8B_CHECK(lpstSourceScreen2);
  SCREEN_CHK_SIZE(lpstSourceScreen1, lpstSourceScreen2);

  if (SCREEN_CLONE(lpstSourceScreen1, lpstDestScreen) == 0)
  {
    for (li32t = 0; li32t < SCREEN_SIZE(lpstDestScreen); li32t++)
    {
      
      if (BPP32_8R8G8B_MEM(li32t, lpstSourceScreen1) > BPP32_8R8G8B_MEM(li32t, lpstSourceScreen2))
      {
        BPP32_8R8G8B_MEM(li32t, lpstDestScreen) = BPP32_8R8G8B_MEM(li32t, lpstSourceScreen1);
      }
      else
      {
        BPP32_8R8G8B_MEM(li32t, lpstDestScreen) = BPP32_8R8G8B_MEM(li32t, lpstSourceScreen2);
      }
    }
  }
  else
  {
    return 2;
  }
  return 0;
}


int8 BPP32_8R8G8B_MINScreen(Screen* lpstSourceScreen1, 
                            Screen* lpstSourceScreen2,
                            Screen* lpstDestScreen)
{
  int32 li32t;

  SCREEN_CHK_INIT(lpstSourceScreen1);
  BPP32_8R8G8B_CHECK(lpstSourceScreen1);
  SCREEN_CHK_INIT(lpstSourceScreen2);
  BPP32_8R8G8B_CHECK(lpstSourceScreen2);
  SCREEN_CHK_SIZE(lpstSourceScreen1, lpstSourceScreen2);

  if (SCREEN_CLONE(lpstSourceScreen1, lpstDestScreen) == 0)
  {
    for (li32t = 0; li32t < SCREEN_SIZE(lpstDestScreen); li32t++)
    {
      
      if (BPP32_8R8G8B_MEM(li32t, lpstSourceScreen1) < BPP32_8R8G8B_MEM(li32t, lpstSourceScreen2))
      {
        BPP32_8R8G8B_MEM(li32t, lpstDestScreen) = BPP32_8R8G8B_MEM(li32t, lpstSourceScreen1);
      }
      else
      {
        BPP32_8R8G8B_MEM(li32t, lpstDestScreen) = BPP32_8R8G8B_MEM(li32t, lpstSourceScreen2);
      }
    }
  }
  else
  {
    return 2;
  }
  return 0;
}



int8 BPP32_8R8G8B_ScallScreen(Screen* lpstSourceScreen, Screen* lpstDestScreen)
{
  uint32 lui32x, lui32y, lui32yy1;

  SCREEN_CHK_INIT(lpstSourceScreen);
  BPP32_8R8G8B_CHECK(lpstSourceScreen);
  SCREEN_CHK_INIT(lpstDestScreen);
  BPP32_8R8G8B_CHECK(lpstDestScreen);

  if ((lpstSourceScreen->ui16Width  == lpstDestScreen->ui16Width) &&
      (lpstSourceScreen->ui16Height == lpstDestScreen->ui16Height))
  {
    return BPP32_8R8G8B_CopyScreenRaw(lpstSourceScreen, lpstDestScreen);
  }
  else
  {
    lui32yy1 = 0;
    for (lui32y = 0 ; lui32y < lpstDestScreen->ui16Height; lui32y++)
    {
     for (lui32x = 0; lui32x < lpstDestScreen->ui16Width; lui32x++)
     {
	     BPP32_8R8G8B_MEM(lui32yy1 + lui32x, lpstDestScreen) = 
           BPP32_8R8G8B_MEM(((lui32y * lpstSourceScreen->ui16Height) / lpstDestScreen->ui16Height) * lpstSourceScreen->ui16Width + 
                            ((lui32x * lpstSourceScreen->ui16Width)  / lpstDestScreen->ui16Width),
                            lpstSourceScreen);
     }

     lui32yy1 += lpstDestScreen->ui16Width;
    }
  }
  return 0;
}



int8 BPP32_8R8G8B_ScreenFlipX(Screen* lpstSourceScreen, Screen* lpstDestScreen)
{
  uint32 lui32x, lui32y, lui32yy1;

  SCREEN_CHK_INIT(lpstSourceScreen);
  BPP32_8R8G8B_CHECK(lpstSourceScreen);

  if (SCREEN_CLONE(lpstSourceScreen, lpstDestScreen) == 0)
  {
    lui32yy1 = 0;
    for (lui32y = 0 ; lui32y < lpstDestScreen->ui16Height; lui32y++)
    {
      for (lui32x = 0; lui32x < lpstDestScreen->ui16Width; lui32x++)
      {
        BPP32_8R8G8B_MEM(lui32yy1 + lui32x, lpstDestScreen) = BPP32_8R8G8B_MEM(lui32yy1 + lpstDestScreen->ui16Width - lui32x, lpstSourceScreen);           
      }

      lui32yy1 += lpstDestScreen->ui16Width;
    }
  }
  else
  {
    return 0;
  }

  return 0;
}

int8 BPP32_8R8G8B_ScreenFlipY(Screen* lpstSourceScreen, Screen* lpstDestScreen)
{
  uint32 lui32x, lui32y, lui32yy1, lui32yy2;

  SCREEN_CHK_INIT(lpstSourceScreen);
  BPP32_8R8G8B_CHECK(lpstSourceScreen);

  if (SCREEN_CLONE(lpstSourceScreen, lpstDestScreen) == 0)
  {
    lui32yy1 = 0;
    lui32yy2 = (lpstDestScreen->ui16Height - 1) * lpstDestScreen->ui16Width;
    for (lui32y = 0 ; lui32y < lpstDestScreen->ui16Height; lui32y++)
    {
      for (lui32x = 0; lui32x < lpstDestScreen->ui16Width; lui32x++)
      {
        BPP32_8R8G8B_MEM(lui32yy1 + lui32x, lpstDestScreen) = BPP32_8R8G8B_MEM(lui32yy2 + lui32x, lpstSourceScreen);           
      }

      lui32yy1 += lpstDestScreen->ui16Width;
      lui32yy2 -= lpstDestScreen->ui16Width;
    }
  }
  else
  {
    return 0;
  }
  return 0;
}


int8 BPP32_8R8G8B_ScreenGrey(Screen* lpstSourceScreen, Screen* lpstDestScreen)
{
  uint32 lui32x,   lui32y, lui32yy1;
  uint32 li32Scol, li32Sr, li32Sg, li32Sb;

  SCREEN_CHK_INIT(lpstSourceScreen);
  BPP32_8R8G8B_CHECK(lpstSourceScreen);

  if (SCREEN_CLONE(lpstSourceScreen, lpstDestScreen) == 0)
  {
    lui32yy1 = 0;
    for (lui32y = 0 ; lui32y < lpstDestScreen->ui16Height; lui32y++)
    {
      for (lui32x = 0; lui32x < lpstDestScreen->ui16Width; lui32x++)
      {
        li32Scol = BPP32_8R8G8B_MEM(lui32yy1 + lui32x, lpstSourceScreen);

        BPP32_8R8G8B_GET_RGB(li32Scol, li32Sr, li32Sg, li32Sb);
        li32Scol = (li32Sr + li32Sg + li32Sb) / 3;
	      BPP32_8R8G8B_MEM(lui32yy1 + lui32x, lpstDestScreen) = BPP32_8R8G8B_RGB(li32Scol, li32Scol, li32Scol);
     }

     lui32yy1 += lpstDestScreen->ui16Width;
    }
  }
  else
  {
    return 0;
  }
  return 0;
}