//--------------------------------------------------------------
// File     : stm32_ub_lcd_ili9325.c
// Datum    : 02.01.2016
// Version  : 1.0
// Autor    : UB
// EMail    : mc-4u(@)t-online.de
// Web      : www.mikrocontroller-4u.de
// CPU      : STM32F4
// IDE      : CooCox CoIDE 1.7.8
// GCC      : 4.9 2015q2
// Module   : GPIO,FSMC
// Funktion : Grafik-LCD Funktionen (Chip=ILI9325)
//            Der Zugriff erfolgt ueber den FSMC-Controller
//            Im 16bit 8080-Mode (5R6G5B = RGB565)
// Hinweis  : Das Display benutzt die CPU-Pins :
//             PB0  -> LCD_Backlight   PE3  -> LCD_RS
//             PD0  -> LCD_DB2         PE7  -> LCD_DB4
//             PD1  -> LCD_DB3         PE8  -> LCD_DB5
//             PD4  -> LCD_RD          PE9  -> LCD_DB6
//             PD5  -> LCD_WR          PE10 -> LCD_DB7
//             PD7  -> LCD_CS          PE11 -> LCD_DB10
//             PD8  -> LCD_DB15        PE12 -> LCD_DB11
//             PD9  -> LCD_DB16        PE13 -> LCD_DB12
//             PD10 -> LCD_DB17        PE14 -> LCD_DB13
//             PD14 -> LCD_DB0         PE15 -> LCD_DB14
//             PD15 -> LCD_DB1
//--------------------------------------------------------------

//--------------------------------------------------------------
// Includes
//--------------------------------------------------------------
#include "ili9341.h"



//--------------------------------------------------------------
// interne Funktionen
//--------------------------------------------------------------
void P_LCD9325_InitIO(void);
void P_LCD9325_InitFSMC(void);
void P_LCD9325_InitChip(uint16_t mode);
uint16_t P_LCD9325_ReadReg(uint8_t reg_adr);
void P_LCD9325_WriteReg(uint8_t reg_adr, uint16_t reg_value);
void P_LCD9325_Delay(volatile uint32_t nCount);


//--------------------------------------------------------------
// Init vom LCD-Display
// Return_wert :
//  -> ERROR   , wenn Display nicht gefunden wurde
//  -> SUCCESS , wenn Display OK (ID=9325)
//--------------------------------------------------------------
ErrorStatus UB_LCD_Init(void)
{
  ErrorStatus ret_wert=ERROR;
  uint16_t lcdid = 0;

  // IO-Lines initialisieren
  P_LCD9325_InitIO();
  // kleine Pause
  P_LCD9325_Delay(LCD_ILI9325_PAUSE);
  // FSMC initialisieren
  P_LCD9325_InitFSMC();
  // kleine Pause
  P_LCD9325_Delay(LCD_ILI9325_PAUSE);

  // LCD-ID auslesen
  lcdid = P_LCD9325_ReadReg(0xda);
  lcdid += P_LCD9325_ReadReg(0xdb);
  lcdid += P_LCD9325_ReadReg(0xdc);
  if(lcdid==LCD_ILI9325_ID) {
    // Display gefunden
    ret_wert=SUCCESS;
    // LCD-Controller initialisieren (Mode=Portrait)
    P_LCD9325_InitChip(LCD_ILI9325_PORTRAIT);
    LCD_DISPLAY_MODE=PORTRAIT;
    // Backlight einschalten
    UB_LCD_Backlight_On();
  }

  LCD_WINDOW.xstart=0;
  LCD_WINDOW.ystart=0;
  LCD_WINDOW.xend=LCD_MAXX-1;
  LCD_WINDOW.yend=LCD_MAXY-1;
  LCD_WINDOW.pixel=LCD_PIXEL;

  return(ret_wert);
}


//--------------------------------------------------------------
// setzt den Cursor auf x,y Position
// und bereitet das schreiben ins Display-RAM vor
//--------------------------------------------------------------
void UB_LCD_SetCursor2Draw(uint16_t xpos, uint16_t ypos)
{
  // Cursor setzen
  P_LCD9325_WriteReg(LCD_ILI9325_REG_20, xpos);
  P_LCD9325_WriteReg(LCD_ILI9325_REG_21, ypos);

  // adresse anlegen
  LCD_REG=LCD_ILI9325_REG_22;
}


//--------------------------------------------------------------
// F�llt den Screen mit einer Farbe
//--------------------------------------------------------------
void UB_LCD_FillScreen(uint16_t color)
{
  uint32_t n = 0;

  // Cursor auf 0 setzen
  UB_LCD_SetCursor2Draw(LCD_WINDOW.xstart,LCD_WINDOW.ystart);
  // Komplettes Display beschreiben
  for(n=0;n<LCD_WINDOW.pixel;n++) {
    LCD_RAM = color;
  }
}


//--------------------------------------------------------------
// Backlight einschalten
//--------------------------------------------------------------
void UB_LCD_Backlight_On(void)
{
  GPIOB->BSRRH = GPIO_Pin_0;
}


//--------------------------------------------------------------
// Backlight ausschalten
//--------------------------------------------------------------
void UB_LCD_Backlight_Off(void)
{
  GPIOB->BSRRL = GPIO_Pin_0;
}

//--------------------------------------------------------------
// Screen-Mode einstellen
// muss direkt nach dem Init gemacht werden
//
// Mode : [PORTRAIT=default, LANDSCAPE]
//--------------------------------------------------------------
void UB_LCD_SetMode(LCD_MODE_t mode)
{
  if(mode==PORTRAIT) {
    P_LCD9325_InitChip(LCD_ILI9325_PORTRAIT);
    LCD_DISPLAY_MODE=PORTRAIT;
  }
  else {
    P_LCD9325_InitChip(LCD_ILI9325_LANDSCAPE);
    LCD_DISPLAY_MODE=LANDSCAPE;
  }
}


//--------------------------------------------------------------
// stellt ein Display-Fenster zum zeichnen ein
// von xtart,ystart zu xend,yend
//--------------------------------------------------------------
void UB_LCD_SetWindow(uint16_t xstart, uint16_t ystart, uint16_t xend, uint16_t yend)
{
  P_LCD9325_WriteReg(LCD_ILI9325_REG_50, xstart);
  P_LCD9325_WriteReg(LCD_ILI9325_REG_51, xend);
  P_LCD9325_WriteReg(LCD_ILI9325_REG_52, ystart);
  P_LCD9325_WriteReg(LCD_ILI9325_REG_53, yend);

  LCD_WINDOW.xstart=xstart;
  LCD_WINDOW.ystart=ystart;
  LCD_WINDOW.xend=xend;
  LCD_WINDOW.yend=yend;
  LCD_WINDOW.pixel=(xend-xstart+1)*(yend-ystart+1);
}


//--------------------------------------------------------------
// interne Funktion
// Init aller IO-Pins fuer das Display
//--------------------------------------------------------------
void P_LCD9325_InitIO(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;

  //-----------------------------------------
  // Clock Enable von Port-B, Port-D und Port-E
  //-----------------------------------------
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB,ENABLE);
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD,ENABLE);
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE,ENABLE);

  //-----------------------------------------
  // Alle Pins von Port-B initialisieren
  //-----------------------------------------
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;              //PB0 -> enable Backlight
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  // Config von Port-B
  GPIO_Init(GPIOB, &GPIO_InitStructure);

  //-----------------------------------------
  // Alle Pins von Port-D initialisieren
  //-----------------------------------------
  GPIO_PinAFConfig(GPIOD, GPIO_PinSource0,  GPIO_AF_FSMC); // PD0=FSMC_D2   -> DB2
  GPIO_PinAFConfig(GPIOD, GPIO_PinSource1,  GPIO_AF_FSMC); // PD1=FSMC_D3   -> DB3
  GPIO_PinAFConfig(GPIOD, GPIO_PinSource4,  GPIO_AF_FSMC); // PD4=FSMC_NOE  -> RD
  GPIO_PinAFConfig(GPIOD, GPIO_PinSource5,  GPIO_AF_FSMC); // PD5=FSMC_NWE  -> WR
  GPIO_PinAFConfig(GPIOD, GPIO_PinSource7,  GPIO_AF_FSMC); // PD7=FSMC_NE1  -> CS
  GPIO_PinAFConfig(GPIOD, GPIO_PinSource8,  GPIO_AF_FSMC); // PD8=FSMC_D13  -> DB15
  GPIO_PinAFConfig(GPIOD, GPIO_PinSource9,  GPIO_AF_FSMC); // PD9=FSMC_D14  -> DB16
  GPIO_PinAFConfig(GPIOD, GPIO_PinSource10, GPIO_AF_FSMC); // PD10=FSMC_D15 -> DB17
  GPIO_PinAFConfig(GPIOD, GPIO_PinSource14, GPIO_AF_FSMC); // PD14=FSMC_D0  -> DB0
  GPIO_PinAFConfig(GPIOD, GPIO_PinSource15, GPIO_AF_FSMC); // PD15=FSMC_D1  -> DB1

  // Structur fuer Port-D
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_4 | GPIO_Pin_5 |
                                GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10 |
                                GPIO_Pin_14 | GPIO_Pin_15;

  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_NOPULL;
  // Config von Port-D
  GPIO_Init(GPIOD, &GPIO_InitStructure);

  //-----------------------------------------
  // Alle Pins von Port-E initialisieren
  //-----------------------------------------
  GPIO_PinAFConfig(GPIOE, GPIO_PinSource3,  GPIO_AF_FSMC); // PE3=FSMC_A19  -> RS
  GPIO_PinAFConfig(GPIOE, GPIO_PinSource7,  GPIO_AF_FSMC); // PE7=FSMC_D4   -> DB4
  GPIO_PinAFConfig(GPIOE, GPIO_PinSource8,  GPIO_AF_FSMC); // PE8=FSMC_D5   -> DB5
  GPIO_PinAFConfig(GPIOE, GPIO_PinSource9,  GPIO_AF_FSMC); // PE9=FSMC_D6   -> DB6
  GPIO_PinAFConfig(GPIOE, GPIO_PinSource10, GPIO_AF_FSMC); // PE10=FSMC_D7  -> DB7
  GPIO_PinAFConfig(GPIOE, GPIO_PinSource11, GPIO_AF_FSMC); // PE11=FSMC_D8  -> DB10
  GPIO_PinAFConfig(GPIOE, GPIO_PinSource12, GPIO_AF_FSMC); // PE12=FSMC_D9  -> DB11
  GPIO_PinAFConfig(GPIOE, GPIO_PinSource13, GPIO_AF_FSMC); // PE13=FSMC_D10 -> DB12
  GPIO_PinAFConfig(GPIOE, GPIO_PinSource14, GPIO_AF_FSMC); // PE14=FSMC_D11 -> DB13
  GPIO_PinAFConfig(GPIOE, GPIO_PinSource15, GPIO_AF_FSMC); // PE15=FSMC_D12 -> DB14

  // Structur fuer Port-E
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3 | GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9 |
                                GPIO_Pin_10 | GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_13 |
                                GPIO_Pin_14 | GPIO_Pin_15;

  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_NOPULL;
  // Config von Port-E
  GPIO_Init(GPIOE, &GPIO_InitStructure);

}

//--------------------------------------------------------------
// interne Funktion
// Init vom FSMC fuer das Display
// CS an PD7=FSMC_NE1 = Bank-1 / PSRAM-1
//--------------------------------------------------------------
void P_LCD9325_InitFSMC(void)
{
  FSMC_NORSRAMInitTypeDef        FSMC_NORSRAMInitStructure;
  FSMC_NORSRAMTimingInitTypeDef  FSMC_NORSRAMTimingInitStructure;

  //-----------------------------------------
  // Clock Enable von FSMC
  //-----------------------------------------
  RCC_AHB3PeriphClockCmd(RCC_AHB3Periph_FSMC, ENABLE);

  //-----------------------------------------
  // Structure fuer das Timing
  //-----------------------------------------
  FSMC_NORSRAMTimingInitStructure.FSMC_AddressSetupTime = LCD_ILI9325_FSMC_AST;
  FSMC_NORSRAMTimingInitStructure.FSMC_AddressHoldTime = 1;
  FSMC_NORSRAMTimingInitStructure.FSMC_DataSetupTime = LCD_ILI9325_FSMC_DST;
  FSMC_NORSRAMTimingInitStructure.FSMC_BusTurnAroundDuration = 0;
  FSMC_NORSRAMTimingInitStructure.FSMC_CLKDivision = 0;
  FSMC_NORSRAMTimingInitStructure.FSMC_DataLatency = 0;
  FSMC_NORSRAMTimingInitStructure.FSMC_AccessMode = FSMC_AccessMode_A;

  //-----------------------------------------
  // Structure fuer Bank-1 / PSRAM-1
  //-----------------------------------------
  FSMC_NORSRAMInitStructure.FSMC_Bank = FSMC_Bank1_NORSRAM1;
  FSMC_NORSRAMInitStructure.FSMC_DataAddressMux = FSMC_DataAddressMux_Disable;
  FSMC_NORSRAMInitStructure.FSMC_MemoryType = FSMC_MemoryType_SRAM;
  FSMC_NORSRAMInitStructure.FSMC_MemoryDataWidth = FSMC_MemoryDataWidth_16b;
  FSMC_NORSRAMInitStructure.FSMC_BurstAccessMode = FSMC_BurstAccessMode_Disable;
  FSMC_NORSRAMInitStructure.FSMC_AsynchronousWait = FSMC_AsynchronousWait_Disable;
  FSMC_NORSRAMInitStructure.FSMC_WaitSignalPolarity = FSMC_WaitSignalPolarity_Low;
  FSMC_NORSRAMInitStructure.FSMC_WrapMode = FSMC_WrapMode_Disable;
  FSMC_NORSRAMInitStructure.FSMC_WaitSignalActive = FSMC_WaitSignalActive_BeforeWaitState;
  FSMC_NORSRAMInitStructure.FSMC_WriteOperation = FSMC_WriteOperation_Enable;
  FSMC_NORSRAMInitStructure.FSMC_WaitSignal = FSMC_WaitSignal_Disable;
  FSMC_NORSRAMInitStructure.FSMC_ExtendedMode = FSMC_ExtendedMode_Disable;
  FSMC_NORSRAMInitStructure.FSMC_WriteBurst = FSMC_WriteBurst_Disable;
  FSMC_NORSRAMInitStructure.FSMC_ReadWriteTimingStruct = &FSMC_NORSRAMTimingInitStructure;
  FSMC_NORSRAMInitStructure.FSMC_WriteTimingStruct = &FSMC_NORSRAMTimingInitStructure;

  // Config vom FSMC
  FSMC_NORSRAMInit(&FSMC_NORSRAMInitStructure);

  // Enable Bank-1 / PSRAM-1
  FSMC_NORSRAMCmd(FSMC_Bank1_NORSRAM1, ENABLE);
}

//--------------------------------------------------------------
// interne Funktion
// initialisiert den ILI9325-Controller im Display
// mode :  0x1030=Portrait, 0x1038=Landscape
//--------------------------------------------------------------
void P_LCD9325_InitChip(uint16_t mode)
{
  P_LCD9325_WriteReg(0x00e7,0x0010);
  P_LCD9325_WriteReg(0x0000,0x0001);
  P_LCD9325_WriteReg(0x0001,0x0100);
  P_LCD9325_WriteReg(0x0002,0x0700);
  P_LCD9325_WriteReg(LCD_ILI9325_REG_03,mode);   // Portrait, Landscape
  P_LCD9325_WriteReg(0x0004,0x0000);
  P_LCD9325_WriteReg(0x0008,0x0207);
  P_LCD9325_WriteReg(0x0009,0x0000);
  P_LCD9325_WriteReg(0x000a,0x0000);
  P_LCD9325_WriteReg(0x000c,0x0001);
  P_LCD9325_WriteReg(0x000d,0x0000);
  P_LCD9325_WriteReg(0x000f,0x0000);
  P_LCD9325_WriteReg(0x0010,0x0000);
  P_LCD9325_WriteReg(0x0011,0x0007);
  P_LCD9325_WriteReg(0x0012,0x0000);
  P_LCD9325_WriteReg(0x0013,0x0000);
  // kleine pause
  P_LCD9325_Delay(LCD_ILI9325_PAUSE);
  P_LCD9325_WriteReg(0x0010,0x1590);
  P_LCD9325_WriteReg(0x0011,0x0227);
  // kleine pause
  P_LCD9325_Delay(LCD_ILI9325_PAUSE);
  P_LCD9325_WriteReg(0x0012,0x009c);
  // kleine pause
  P_LCD9325_Delay(LCD_ILI9325_PAUSE);
  P_LCD9325_WriteReg(0x0013,0x1900);
  P_LCD9325_WriteReg(0x0029,0x0023);
  P_LCD9325_WriteReg(0x002b,0x000e);
  // kleine pause
  P_LCD9325_Delay(LCD_ILI9325_PAUSE);
  P_LCD9325_WriteReg(0x0020,0x0000);
  P_LCD9325_WriteReg(0x0021,0x0000);
  // kleine pause
  P_LCD9325_Delay(LCD_ILI9325_PAUSE);
  P_LCD9325_WriteReg(0x0030,0x0007);
  P_LCD9325_WriteReg(0x0031,0x0707);
  P_LCD9325_WriteReg(0x0032,0x0006);
  P_LCD9325_WriteReg(0x0035,0x0704);
  P_LCD9325_WriteReg(0x0036,0x1f04);
  P_LCD9325_WriteReg(0x0037,0x0004);
  P_LCD9325_WriteReg(0x0038,0x0000);
  P_LCD9325_WriteReg(0x0039,0x0706);
  P_LCD9325_WriteReg(0x003c,0x0701);
  P_LCD9325_WriteReg(0x003d,0x000f);
  // kleine pause
  P_LCD9325_Delay(LCD_ILI9325_PAUSE);
  P_LCD9325_WriteReg(0x0050,0x0000); // Horizontal Start
  P_LCD9325_WriteReg(0x0051,0x00ef); // Horizontal Ende
  P_LCD9325_WriteReg(0x0052,0x0000); // Vertikal Start
  P_LCD9325_WriteReg(0x0053,0x013f); // Vertikal Ende
  P_LCD9325_WriteReg(0x0060,0xA700);
  P_LCD9325_WriteReg(0x0061,0x0001);
  P_LCD9325_WriteReg(0x006a,0x0000);
  P_LCD9325_WriteReg(0x0080,0x0000);
  P_LCD9325_WriteReg(0x0081,0x0000);
  P_LCD9325_WriteReg(0x0082,0x0000);
  P_LCD9325_WriteReg(0x0083,0x0000);
  P_LCD9325_WriteReg(0x0084,0x0000);
  P_LCD9325_WriteReg(0x0085,0x0000);
  P_LCD9325_WriteReg(0x0090,0x0010);
  P_LCD9325_WriteReg(0x0092,0x0000);
  P_LCD9325_WriteReg(0x0093,0x0003);
  P_LCD9325_WriteReg(0x0095,0x0110);
  P_LCD9325_WriteReg(0x0097,0x0000);
  P_LCD9325_WriteReg(0x0098,0x0000);
  P_LCD9325_WriteReg(0x0007,0x0133);
  P_LCD9325_WriteReg(0x0020,0x0000);
  P_LCD9325_WriteReg(0x0021,0x0000);
  // kleine pause
  P_LCD9325_Delay(LCD_ILI9325_PAUSE);
}

//--------------------------------------------------------------
// interne Funktion
// einen Wert aus einem Register auslesen
//--------------------------------------------------------------
uint16_t P_LCD9325_ReadReg(uint8_t reg_adr)
{
  // adresse anlegen
  LCD_REG = reg_adr;
  // wert auslesen
  return LCD_RAM;
}

//--------------------------------------------------------------
// interne Funktion
// einen Wert in eine Register schreiben
//--------------------------------------------------------------
void P_LCD9325_WriteReg(uint8_t reg_adr, uint16_t reg_value)
{
  // adresse anlegen
  LCD_REG = reg_adr;
  // wert schreiben
  LCD_RAM = reg_value;
}


//--------------------------------------------------------------
// kleine Pause (ohne Timer)
//--------------------------------------------------------------
void P_LCD9325_Delay(volatile uint32_t nCount)
{
  while(nCount--)
  {
  }
}
