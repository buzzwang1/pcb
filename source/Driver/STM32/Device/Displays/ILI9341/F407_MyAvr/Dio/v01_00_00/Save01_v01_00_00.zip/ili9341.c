#include "ili9341.h"

// Hinweis  : Das Display benutzt die CPU-Pins :
//             PB9  -> LCD_Backlight

//             PB1  -> LCD_RS
//             PB2  -> LCD_RD
//             PB0  -> LCD_WR
//             PB4  -> LCD_CS
//             PB3  -> LCD_Reset

//             PD8  -> LCD_DB0
//             PD9  -> LCD_DB1
//             PD10 -> LCD_DB2
//             PD11 -> LCD_DB3
//             PE4  -> LCD_DB4
//             PE5  -> LCD_DB5
//             PE6  -> LCD_DB6
//             PE7  -> LCD_DB7
//             PE8  -> LCD_DB8
//             PE9  -> LCD_DB9
//             PE10 -> LCD_DB10
//             PE11 -> LCD_DB11
//             PE12 -> LCD_DB12
//             PE13 -> LCD_DB13
//             PE14 -> LCD_DB14
//             PE15 -> LCD_DB15

#define nCS     GPIO_Pin_4
#define RS      GPIO_Pin_1
#define nWR     GPIO_Pin_0
#define nRD     GPIO_Pin_2
#define nReset  GPIO_Pin_3
#define LCD_BK  GPIO_Pin_9


#define ILI9341_Dio_Set_CS() GPIO_SetBits(GPIOB, nCS)
#define ILI9341_Dio_Clr_CS() GPIO_ResetBits(GPIOB,   nCS)

#define ILI9341_Dio_Set_RS() GPIO_SetBits(GPIOB,   RS)
#define ILI9341_Dio_Clr_RS() GPIO_ResetBits(GPIOB, RS)
#define ILI9341_Dio_RS_Data() ILI9341_Dio_Set_RS()
#define ILI9341_Dio_RS_Cmd()  ILI9341_Dio_Clr_RS()

#define ILI9341_Dio_Set_RD() GPIO_SetBits(GPIOB, nRD)
#define ILI9341_Dio_Clr_RD() GPIO_ResetBits(GPIOB,   nRD)

#define ILI9341_Dio_Set_WR() GPIO_SetBits(GPIOB, nWR)
#define ILI9341_Dio_Clr_WR() GPIO_ResetBits(GPIOB,   nWR)

#define ILI9341_Dio_Set_BL() GPIO_SetBits(GPIOB, LCD_BK)
#define ILI9341_Dio_Clr_BL() GPIO_ResetBits(GPIOB,   LCD_BK)

#define ILI9341_Dio_Set_Reset() GPIO_SetBits(GPIOB, nReset)
#define ILI9341_Dio_Clr_Reset() GPIO_ResetBits(GPIOB,   nReset)

#define ILI9341_Dio_Set_Data_Out() GPIOD->MODER |= 0x00550000;GPIOE->MODER |= 0x55555500;
#define ILI9341_Dio_Set_Data_In()  GPIOD->MODER &= 0xFF00FFFF;GPIOE->MODER &= 0x000000FF;


void ILI9341_Set_Dio_Data(uint16 lui16Data)
{
  uint16 lui16DataD;
  uint16 lui16DataE;

  lui16DataD  = (GPIOD->ODR & 0xF0FF);
  lui16DataD |= ((lui16Data & 0x000F) << 8);

  lui16DataE  = (GPIOD->ODR & 0x000F);
  lui16DataE |= (lui16Data & 0xFFF0);

  GPIOD->ODR  = lui16DataD;
  GPIOE->ODR  = lui16DataE;

  ILI9341_Dio_Clr_WR();
  ILI9341_Dio_Set_WR();
}

uint16 ILI9341_Dio_Get_Data()
{
  uint16 lui16Data;

  ILI9341_Dio_Clr_RD();
  lui16Data =  (GPIO_ReadInputData(GPIOD) >> 8) & 0x0F;
  lui16Data |= (GPIO_ReadInputData(GPIOE) & 0xFFF0);
  ILI9341_Dio_Set_RD();

  return lui16Data;
}

void ILI9341_WriteReg(uint16 lui16Index, uint16 lui16Data)
{
 /************************************************************************
  **                                                                    **
  ** nCS       ----\__________________________________________/-------  **
  ** RS        ------\____________/-----------------------------------  **
  ** nRD       -------------------------------------------------------  **
  ** nWR       --------\_______/--------\_____/-----------------------  **
  ** DB[0:15]  ---------[index]----------[data]-----------------------  **
  **                                                                    **
  ************************************************************************/
  ILI9341_Dio_Set_CS();
    ILI9341_Dio_Set_Data_Out();
      ILI9341_Dio_RS_Cmd();  ILI9341_Set_Dio_Data(lui16Index);
      ILI9341_Dio_RS_Data(); ILI9341_Set_Dio_Data(lui16Data);
    ILI9341_Dio_Set_Data_In();
  ILI9341_Dio_Clr_CS();
}

void TFT_24S_Write_Command(uint16 lui16Data)
{
  ILI9341_Dio_Clr_CS();
    ILI9341_Dio_Set_RD();
    ILI9341_Dio_Set_Data_Out();
      ILI9341_Dio_RS_Cmd();
      ILI9341_Set_Dio_Data(lui16Data);
}

void TFT_24S_Write_Data(uint16 lui16Data)
{
  ILI9341_Dio_Clr_CS();
    ILI9341_Dio_Set_RD();
    ILI9341_Dio_Set_Data_Out();
      ILI9341_Dio_RS_Data();
      ILI9341_Set_Dio_Data(lui16Data);
}

uint16 ILI9341_ReadReg(uint16 lui16Index)
{
 /************************************************************************
  **                                                                    **
  ** nCS       ----\__________________________________________/-------  **
  ** RS        ------\____________/-----------------------------------  **
  ** nRD       -------------------------\______/----------------------  **
  ** nWR       --------\_______/--------------------------------------  **
  ** DB[0:15]  ---------[index]----------[data]-----------------------  **
  **                                                                    **
  ************************************************************************/
  uint16 lui16Data;

  ILI9341_Dio_Clr_CS();
    ILI9341_Dio_Set_Data_Out();
      ILI9341_Dio_RS_Cmd();
        ILI9341_Set_Dio_Data(lui16Index);
      ILI9341_Dio_RS_Data();

    ILI9341_Dio_Set_Data_In();
      lui16Data = ILI9341_Dio_Get_Data();
      //lui16Data = ILI9341_Dio_Get_Data();
  ILI9341_Dio_Set_CS();

  return lui16Data;
}

uint32 ILI9341_DisplayStatus(void)
{
 /************************************************************************
  **                                                                    **
  ** nCS       ----\__________________________________________/-------  **
  ** RS        ------\____________/-----------------------------------  **
  ** nRD       -------------------------\______/----------------------  **
  ** nWR       --------\_______/--------------------------------------  **
  ** DB[0:15]  ---------[index]----------[data]-----------------------  **
  **                                                                    **
  ************************************************************************/
  uint32 lui32Data;

  ILI9341_Dio_Clr_CS();
    ILI9341_Dio_Set_Data_Out();
      ILI9341_Dio_Clr_RS();
        ILI9341_Set_Dio_Data(4);
      ILI9341_Dio_Set_RS();

    ILI9341_Dio_Set_Data_In();

      lui32Data = 0;
      lui32Data += ILI9341_Dio_Get_Data() & 0xFF;
      lui32Data <<= 8;

      lui32Data += ILI9341_Dio_Get_Data() & 0xFF;
      lui32Data <<= 8;

      lui32Data += ILI9341_Dio_Get_Data() & 0xFF;
      lui32Data <<= 8;

      lui32Data += ILI9341_Dio_Get_Data() & 0xFF;

  ILI9341_Dio_Set_CS();

  return lui32Data;
}


void ILI9341_InitIO(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;

  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB,ENABLE);
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD,ENABLE);
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE,ENABLE);
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOH,ENABLE);

  GPIO_InitStructure.GPIO_Pin   = LCD_BK | nCS | nWR | RS | nRD | nReset;
  GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_OUT;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_UP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOB, &GPIO_InitStructure);

  //GPIO_InitStructure.GPIO_Pin   = nReset;
  //GPIO_Init(GPIOH, &GPIO_InitStructure);

  // Structur fuer Port-D
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10 | GPIO_Pin_11;
  GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_IN;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_UP;
  // Config von Port-D
  GPIO_Init(GPIOD, &GPIO_InitStructure);

  // Structur fuer Port-E
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4  | GPIO_Pin_5  | GPIO_Pin_6  | GPIO_Pin_7 |
                                GPIO_Pin_8  | GPIO_Pin_9  | GPIO_Pin_10 | GPIO_Pin_11 |
                                GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15;
  GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_IN;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_UP;
  // Config von Port-E
  GPIO_Init(GPIOE, &GPIO_InitStructure);
}


void ILI9341_Delay(uint32 nCount)
{
  for(; nCount != 0; nCount--);
}


void TFT_SetCurPos(uint16_t ulStartX, uint16_t ulEndX, uint16_t ulStartY, uint16_t ulEndY)
{

	TFT_24S_Write_Command(0x002a);
	TFT_24S_Write_Data((ulStartX>>8) & 0x00ff);
	TFT_24S_Write_Data(ulStartX & 0x00ff);
	TFT_24S_Write_Data((ulEndX>>8) & 0x00ff);
	TFT_24S_Write_Data((ulEndX) & 0x00ff);

     TFT_24S_Write_Command(0x002b);
     TFT_24S_Write_Data((ulStartY>>8) & 0x00ff);
     TFT_24S_Write_Data((ulStartY) & 0x00ff);
     TFT_24S_Write_Data((ulEndY>>8) & 0x00ff);
     TFT_24S_Write_Data(ulEndY & 0x00ff);
     TFT_24S_Write_Command(0x002c);
 }

 void TFT_Clear(uint8_t ulColor)
 {
     unsigned long ulTemp;

  //
// Clear LCD
     //
     TFT_SetCurPos(0, 239, 0, 319);

     for(ulTemp = 0; ulTemp <= 239 * 319; ulTemp++)
     {
    	 TFT_24S_Write_Data((ulColor>>8) & 0x00FF);
    	 TFT_24S_Write_Data((ulColor) & 0x00FF);

     }
 }


uint8 ILI9341_Init(void)
{
  uint8 ret_wert = 1;
  uint32 lui32UID;

  // IO-Lines initialisieren
  ILI9341_InitIO();

  ILI9341_Dio_Set_CS();
  ILI9341_Dio_Set_RS();
  ILI9341_Dio_Set_RD();
  ILI9341_Dio_Set_WR();

  ILI9341_Dio_Clr_BL();

  ILI9341_Dio_Clr_Reset();
  ILI9341_Delay(500000);
  ILI9341_Dio_Set_Reset();
  ILI9341_Delay(500000);

  ILI9341_Dio_Set_CS();
    ILI9341_Dio_Set_Data_Out();
      ILI9341_Dio_RS_Cmd();
        ILI9341_Set_Dio_Data(1);
    ILI9341_Dio_Set_Data_In();
  ILI9341_Dio_Clr_CS();

  ILI9341_Delay(500000);

  // LCD-ID auslesen
  //lui32UID = ILI9341_DisplayStatus();
  lui32UID += ILI9341_ReadReg(ILI9341_REG_ID1);
  lui32UID <<= 8;
  lui32UID += ILI9341_ReadReg(ILI9341_REG_ID2);
  lui32UID <<= 8;
  lui32UID += ILI9341_ReadReg(ILI9341_REG_ID3);


  if(lui32UID == ILI9341_ID)
  {
    // Display gefunden
    ret_wert = 0;

    // LCD-Controller initialisieren (Mode=Portrait)
    //P_LCD9325_InitChip(LCD_ILI9325_PORTRAIT);
    // Backlight einschalten
    ILI9341_Dio_Set_BL();
  }


	TFT_24S_Write_Command(0x0028); //display OFF
	TFT_24S_Write_Command(0x0011); //exit SLEEP mode
	TFT_24S_Write_Data(0x0000);
	TFT_24S_Write_Command(0x00CB); //Power Control A
	TFT_24S_Write_Data(0x0039); //always 0x39
	TFT_24S_Write_Data(0x002C); //always 0x2C
	TFT_24S_Write_Data(0x0000); //always 0x00
	TFT_24S_Write_Data(0x0034); //Vcore = 1.6V
	TFT_24S_Write_Data(0x0002); //DDVDH = 5.6V
	TFT_24S_Write_Command(0x00CF); //Power Control B
	TFT_24S_Write_Data(0x0000); //always 0x00
	TFT_24S_Write_Data(0x0081); //PCEQ off
	TFT_24S_Write_Data(0x0030); //ESD protection
	TFT_24S_Write_Command(0x00E8); //Driver timing control A
	TFT_24S_Write_Data(0x0085); //non-overlap
	TFT_24S_Write_Data(0x0001); //EQ timing
	TFT_24S_Write_Data(0x0079); //Pre-charge timing
	TFT_24S_Write_Command(0x00EA); //Driver timing control B
	TFT_24S_Write_Data(0x0000); //Gate driver timing
	TFT_24S_Write_Data(0x0000); //always 0x00
	TFT_24S_Write_Command(0x00ED); //Power-On sequence control
	TFT_24S_Write_Data(0x0064); //soft start
	TFT_24S_Write_Data(0x0003); //power on sequence
	TFT_24S_Write_Data(0x0012); //power on sequence
	TFT_24S_Write_Data(0x0081); //DDVDH enhance on
	TFT_24S_Write_Command(0x00F7); //Pump ratio control
	TFT_24S_Write_Data(0x0020); //DDVDH=2xVCI
	TFT_24S_Write_Command(0x00C0); //power control 1
	TFT_24S_Write_Data(0x0026);
	TFT_24S_Write_Data(0x0004); //second parameter for ILI9340 (ignored by ILI9341)
	TFT_24S_Write_Command(0x00C1); //power control 2
	TFT_24S_Write_Data(0x0011);
	TFT_24S_Write_Command(0x00C5); //VCOM control 1
	TFT_24S_Write_Data(0x0035);
	TFT_24S_Write_Data(0x003E);
	TFT_24S_Write_Command(0x00C7); //VCOM control 2
	TFT_24S_Write_Data(0x00BE);
	TFT_24S_Write_Command(0x0036); //memory access control = BGR
	TFT_24S_Write_Data(0x0088);
	TFT_24S_Write_Command(0x00B1); //frame rate control
	TFT_24S_Write_Data(0x0000);
	TFT_24S_Write_Data(0x0010);
	TFT_24S_Write_Command(0x00B6); //display function control
	TFT_24S_Write_Data(0x000A);
	TFT_24S_Write_Data(0x00A2);
	TFT_24S_Write_Command(0x003A); //pixel format = 16 bit per pixel
	TFT_24S_Write_Data(0x0055);
	TFT_24S_Write_Command(0x00F2); //3G Gamma control
	TFT_24S_Write_Data(0x0002); //off
	TFT_24S_Write_Command(0x0026); //Gamma curve 3
	TFT_24S_Write_Data(0x0001);
	TFT_24S_Write_Command(0x002A); //column address set
	TFT_24S_Write_Data(0x0000);
	TFT_24S_Write_Data(0x0000); //start 0x0000
	TFT_24S_Write_Data(0x0000);
	TFT_24S_Write_Data(0x00EF); //end 0x00EF
	TFT_24S_Write_Command(0x002B); //page address set
	TFT_24S_Write_Data(0x0000);
	TFT_24S_Write_Data(0x0000); //start 0x0000
	TFT_24S_Write_Data(0x0001);
	TFT_24S_Write_Data(0x003F); //end 0x013F

  TFT_Clear(0x1234);

  return(ret_wert);
}




/*

void ili9320_SetCursor(u16 x,u16 y)
{
  //LCD_WriteReg(0,0x02,x);
  //LCD_WriteReg(1,0x03,y);


  LCD_WriteReg(32, y);
  LCD_WriteReg(33, 319-x);
  //*(__IO uint16_t *) (Bank1_LCD_C)= 34;
  //LCD_WriteIndex(34);
}



void ili9320_SetWindows(u16 StartX,u16 StartY,u16 EndX,u16 EndY)
{
  LCD_WriteReg(0x0050, StartY); // Horizontal GRAM Start Address
  LCD_WriteReg(0x0051, EndX); // Horizontal GRAM End Address
  LCD_WriteReg(0x0052, 319-StartX); // Vertical GRAM Start Address
  LCD_WriteReg(0x0053, EndY); // Vertical GRAM Start Address

  //LCD_WriteIndex(34);
}


void ili9320_Clear(u16 dat)
{
  u32 i;
  LCD_WriteReg(0x0050, 0); // Horizontal GRAM Start Address
  LCD_WriteReg(0x0051, 239); // Horizontal GRAM End Address
  LCD_WriteReg(0x0052, 0); // Vertical GRAM Start Address
  LCD_WriteReg(0x0053, 319); // Vertical GRAM Start Address
  LCD_WriteReg(32, 0);
  LCD_WriteReg(33, 0);
		//*(__IO uint16_t *) (Bank1_LCD_C)= 34;
  LCD_WriteIndex(34);
  for(i=0;i<76800;i++) LCD_WriteRAM(dat);
}


u16 ili9320_GetPoint(u16 x,u16 y)
{
	//u16 temp;
  	ili9320_SetCursor(x,y);
  	LCD_WriteIndex(34);
  	return (ili9320_BGR2RGB(ili9320_ReadData()));

}

void ili9320_SetPoint(u16 x,u16 y,u16 point)
{

  LCD_WriteReg(32, y);
  LCD_WriteReg(33, 319-x);
  LCD_WriteIndex(34);
  LCD_WriteRAM(point);
}*/


